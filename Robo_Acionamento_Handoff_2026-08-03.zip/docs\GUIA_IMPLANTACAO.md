# Guia de Implantação — Robô Acionamento Mapfre → Sinistro.net

Documento de handoff pra subir esse robô num ambiente novo (ex.: servidor
gerenciado pela TI). Reflete exatamente o que está em produção hoje
(03/08/2026). Não contém segredos (senhas, tokens) — só a estrutura de onde
eles ficam guardados e o que precisa ser preenchido.

## 1. O que o robô faz

RPA que lê o portal "Gestor de Despachantes" da Mapfre (2 contas: Rafael e
Angélica), grava os processos/sinistros num banco local, e abre acionamento
automático na API do Sinistro.net pra cada processo novo, com notificação por
e-mail via Power Automate. Roda em ciclo fixo (hoje: a cada 2h, 08h-18h,
Seg-Sex), sempre lendo o estado atual da Mapfre a cada execução (não é
event-driven).

## 2. Stack

- **Python 3.11**
- **Banco**: DuckDB (arquivo local único, sem servidor) — ver seção 4
- Bibliotecas principais: `requests`, `pandas`, `SQLAlchemy` + `duckdb-engine`,
  `pyodbc` (só pra ler o banco do Sinistro.net, ver seção 6.3), `python-dotenv`,
  `openpyxl` (leitura da planilha de senha), `python-dateutil`, `pytz`

### `requirements.txt` está incompleto — usar esta lista ao reinstalar:
```
pandas==2.2.1
requests==2.31.0
SQLAlchemy==2.0.28
duckdb==1.5.4
duckdb-engine
python-dotenv==1.0.1
pytz==2024.1
pyarrow
pyodbc==5.3.0
openpyxl
python-dateutil
```
(`openpyxl` e `python-dateutil` são usados no código mas não estavam listados
— sem eles, `sincronizar_senhas_planilha()` e o cálculo de agendamento SLA
quebram.)

`pyodbc` também exige o **ODBC Driver 17 ou 18 for SQL Server** instalado no
SO (não é um pacote Python, é driver do Windows/Linux) — necessário só pra
conciliação de duplicidade (seção 6.3).

## 3. Estrutura de arquivos (pasta do projeto)

```
mapfre_api_v3/
├── main.py                          # Orquestrador principal (executar_robo())
├── mapfre_api.py                    # Cliente da API da Mapfre (GestorDespachanteAPI)
├── sinistro_api.py                  # Cliente da API do Sinistro.net + e-mails
├── database.py                      # Toda a camada de banco (DuckDB)
├── config.py                        # Lê .env, expõe flags (SIMULAR_ENVIO_API etc.)
├── funcoes_auxiliares.py            # Helpers (datas, telefone, placa placeholder)
├── auditoria.py                     # Modo auditoria semanal (sexta 18h)
├── executar_robo.ps1                # Wrapper chamado pela Tarefa Agendada
├── .env                             # Config local (não versionado)
├── requirements.txt                 # Incompleto — ver seção 2
├── sql/
│   ├── 01_create_tables_duckdb.sql  # Schema completo (tabelas + views + macros)
│   └── 02_insert_initial_data_duckdb.sql
├── migrar_parquet_para_duckdb.py    # Script de carga inicial (só rodou 1x, histórico)
├── exportar_tabelas_parquet_duckdb.py # Exporta o banco vivo pra parquet (backup)
├── backfill_analista_mapfre.py      # Script pontual, já rodou 1x
├── power automate/                  # JSON + HTML de referência dos 2 flows (não são lidos automaticamente)
├── logs/robo_execucao.log           # Log de execução (append-only)
└── docs/DOCUMENTACAO_PROJETO.md     # Histórico técnico completo de todas as decisões
```

## 4. Banco de dados

**DuckDB, arquivo único local** — hoje em `C:\Users\saulo.sapucaia\BancoRobo\robo_acionamento.duckdb`
(~9GB+). **Não é servidor**, é biblioteca embutida no processo Python.

- **Single-writer**: só 1 processo pode ter o arquivo aberto pra escrita por
  vez. Um segundo processo tentando abrir enquanto o robô roda recebe
  `IOException`. Isso é o motivo de o robô ter `MultipleInstances=IgnoreNew`
  na Tarefa Agendada (nunca duas execuções simultâneas).
- **Não rodar sobre compartilhamento de rede (SMB/M:\)** — mesma classe de
  problema que travou o Git nessa migração; o arquivo vivo precisa estar em
  disco local do servidor que vai rodar o robô.
- No ambiente novo: criar o schema do zero com `sql/01_create_tables_duckdb.sql`
  (cria 32 tabelas + views + macros), depois `02_insert_initial_data_duckdb.sql`
  (dados de domínio: status, tipos, etc.). Pra trazer o histórico de produção,
  copiar o `.duckdb` vivo direto (mais simples que reexportar parquet).
- Rotina de backup: `executar_robo.ps1` copia o `.duckdb` inteiro pra um
  compartilhamento de rede 1x/dia (18h), com cópia atômica (`.tmp` +
  rename). Precisa ser recriado equivalente no ambiente novo se quiser manter
  a mesma proteção.

## 5. Configuração (`.env`)

```
DUCKDB_PATH=<caminho absoluto do arquivo .duckdb no novo servidor>
AMBIENTE=PRODUCAO
SIMULAR_ENVIO_API=False
PULAR_CONCILIACAO_SINISTRONET=False
```

- `SIMULAR_ENVIO_API=True` faz o robô rodar sem tocar na API real do
  Sinistro.net (útil pra teste no ambiente novo antes de ir ao ar).
- `PULAR_CONCILIACAO_SINISTRONET` é um flag temporário (ver seção 6.3) —
  manter `False` em operação normal.

## 6. Credenciais e parâmetros (dentro do banco, não em arquivo)

Todas as credenciais/config de negócio ficam em tabelas `tb_config_*` do
próprio DuckDB, não em variável de ambiente. No banco novo (se recriado do
zero via schema, não copiado do vivo), popular manualmente:

### 6.1 `tb_config_credenciais` (login Mapfre)
2 linhas ativas (`tb_config_sistema='Mapfre'`), uma por conta (Rafael,
Angélica) — login + senha do portal Gestor de Despachantes. **Não editar
senha aqui diretamente**: o robô lê e sobrescreve sozinho a partir da
planilha de controle (seção 8).

### 6.2 `tb_config_api_sinistronet`
1 linha: URL base da API do Sinistro.net + client ID + client secret (usados
no fluxo de autenticação `POST /login` da API deles) + timeout.

### 6.3 `tb_config_banco_sinistronet`
1 linha: servidor Azure SQL do Sinistro.net (`asinistro.database.windows.net`),
nome do banco, usuário — usado **só pra leitura** da view `Tb_VwEstoqueCompleto`
(conciliação de duplicidade, 1x/dia). **Requer liberação de firewall no Azure
SQL deles pro IP público do servidor novo** — sem isso a conciliação falha
silenciosamente (loga aviso, não trava o robô) e o robô roda sem esse
pré-check local, contando só com o 409 do próprio Sinistro.net como rede de
segurança. **Nunca usar a view `vw_EstoqueCompleto`** (só a tabela
`Tb_VwEstoqueCompleto`) — restrição confirmada, a view pode sobrecarregar o
banco deles.

### 6.4 `tb_config_parametros_robo`
5 chaves: `WEBHOOK_POWER_AUTOMATE`, `WEBHOOK_POWER_AUTOMATE_ERRO` (URLs dos 2
flows, seção 7), `ID_SOLICITANTE`, `ID_SERVICO`, `ID_NATUREZA` (parâmetros
fixos do payload de acionamento no Sinistro.net).

## 7. Integrações externas necessárias

| Sistema | Uso | Frequência |
|---|---|---|
| Mapfre Gestor de Despachantes (API REST) | Login + leitura de processos + detalhe | Toda execução |
| Sinistro.net API REST | Abrir acionamento | Toda execução (quando há fila) |
| Sinistro.net Azure SQL (leitura) | Conciliação de duplicidade | 1x/dia (cacheado) |
| Power Automate — Fluxo "envio de e-mail" | E-mail por processo (sucesso/erro/conflito) | A cada acionamento |
| Power Automate — Fluxo "e-mail API Erro" | Alerta de falha crítica do robô | Só em falha total |

Os 2 flows do Power Automate **não são versionados/deployados por código** —
são flows manuais no portal do Power Automate; os arquivos em `power automate/`
(JSON de schema + HTML) são só referência pra colar no designer se precisar
recriar. Se o ambiente novo tiver conta Microsoft diferente, os flows
precisam ser recriados lá e as URLs de webhook atualizadas em
`tb_config_parametros_robo`.

## 8. Rotina de troca de senha (sem intervenção manual no banco)

Arquivo `Controle_Senhas_Mapfre.xlsx` (hoje em compartilhamento de rede,
colunas Conta/Senha/Instrucao) — o robô lê no Passo 1 de toda execução
(`database.sincronizar_senhas_planilha()`) e aplica sozinho qualquer senha
diferente da que está salva. Só editar a célula da conta, sem tocar em banco
ou código. Precisa recriar esse arquivo (ou local equivalente acessível)
no ambiente novo, apontado em `database.CAMINHO_PLANILHA_SENHAS`.

## 9. Agendamento (hoje: Windows Task Scheduler)

Tarefa `Robo_Acionamento_Mapfre`:
- **Gatilho**: semanal, Segunda a Sexta, 08h às 18h, repetindo a cada 2h
  (08/10/12/14/16/18)
- **Ação**: `powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle
  Hidden -File executar_robo.ps1` (não chama `python.exe` direto — o wrapper
  existe só pra capturar toda a saída no log, ver `executar_robo.ps1`)
- **ExecutionTimeLimit**: 1h (calculado a partir do histórico real de
  duração — modo enriquecimento pode passar de 40min)
- **MultipleInstances**: `IgnoreNew` (nunca duas execuções simultâneas —
  crítico por causa do single-writer do DuckDB)
- **Executar como**: usuário com `LogonType=Interactive` (necessário hoje só
  porque o log/backup grava em compartilhamento de rede mapeado por sessão
  interativa do Windows — **não é mais necessário se o `.duckdb`, os logs e o
  backup ficarem em disco local do servidor novo**, o que é justamente o
  cenário ideal de um ambiente dedicado de TI)

**No ambiente novo, isso pode e deve ser recriado com a ferramenta de
agendamento nativa de lá** (cron, systemd timer, Task Scheduler de novo, etc.)
— só precisa preservar: intervalo de 2h em horário comercial (Seg-Sex),
timeout de ~1h, e garantir que nunca rode 2 instâncias ao mesmo tempo.

### 9.1 Comportamento especial por horário (dentro do próprio `main.py`)
- **8h e 14h → MODO ENRIQUECIMENTO**: reprocessa processos já existentes
  (atualiza dados), não envia nada pro Sinistro.net (termina antes dessa
  etapa por segurança)
- **Sexta 18h → MODO AUDITORIA DE LIMPEZA**: varre processos parados há
  >15 dias, confere status real na Mapfre, dá baixa sozinho nos que já
  finalizaram/cancelaram lá
- **Qualquer outro horário → MODO CAPTURA** (fluxo normal: lê, grava,
  concilia, envia)

Esses gatilhos são só checagem de hora do relógio dentro do Python
(`main.py`), não dependem de configuração externa do agendador — funcionam
igual em qualquer scheduler novo, desde que a hora do sistema esteja certa.

## 10. Limitações conhecidas (não resolvidas, aceitas conscientemente)

- **Crash intermitente do interpretador Python** (`Fatal Python error:
  PyEval_SaveThread`) — já ocorreu 4x, sempre em modo enriquecimento
  (execuções longas). Não é bug do nosso código, é um problema raro de
  threading do CPython/Windows. Defesas já existentes: `limpar_execucoes_
  travadas()` limpa registros presos automaticamente, o wrapper propaga o
  código de saída real pro agendador. Sem causa raiz corrigida — só
  monitorado.
- **Firewall do Azure SQL do Sinistro.net** pode bloquear o IP do servidor
  a qualquer momento (já aconteceu 1x) — quando isso acontece, a conciliação
  falha e loga aviso, mas o robô continua funcionando (usa só o 409 da API
  como defesa). Precisa contato com o time do Sinistro.net pra liberar IP.

## 11. Roteiro de implantação (resumo prático)

1. Instalar Python 3.11 + dependências (seção 2, incluindo driver ODBC)
2. Copiar toda a pasta do projeto pro servidor novo
3. Criar `.env` com o caminho novo do `.duckdb` (disco local do servidor)
4. Rodar `sql/01_create_tables_duckdb.sql` + `02_insert_initial_data_duckdb.sql`
   OU copiar o `.duckdb` de produção direto (mais simples, já vem com
   histórico)
5. Popular/confirmar as 4 tabelas de config (seção 6) com credenciais válidas
6. Criar/apontar a planilha de controle de senha (seção 8)
7. Testar com `SIMULAR_ENVIO_API=True` primeiro — confirma login Mapfre,
   leitura de processos, sem tocar no Sinistro.net real
8. Confirmar os 2 webhooks do Power Automate resolvem (testar 1 envio)
9. Virar `SIMULAR_ENVIO_API=False`, rodar 1x manual, validar no banco
10. Configurar o agendamento novo (seção 9), com timeout e proteção contra
    execução simultânea
