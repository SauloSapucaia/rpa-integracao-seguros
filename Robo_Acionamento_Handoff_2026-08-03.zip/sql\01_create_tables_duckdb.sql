-- =========================================================================
-- PROJETO: Integração RPA Mapfre -> Sinistro.net
-- BANCO DE DADOS: versão DuckDB do schema oficial (sql/01_create_tables.sql
-- continua sendo a referência conceitual; este arquivo é a tradução de
-- sintaxe T-SQL -> DuckDB, mesmas 31 tabelas e 2 views, mesmos nomes PT-BR).
--
-- POR QUE DUCKDB: TI não vai disponibilizar banco, Azure está bloqueado
-- pelo tenant, e o usuário não tem direitos de administrador nesta máquina
-- (confirmado via WindowsPrincipal) -- então SQL Server Express/PostgreSQL
-- local (que exigem instalar serviço) ficaram inviáveis. DuckDB é biblioteca
-- Python pura (pip install, sem admin), embutida no processo (sem servidor).
--
-- DIFERENÇAS DE SINTAXE EM RELAÇÃO AO sql/01_create_tables.sql (T-SQL):
--   IDENTITY(1,1)         -> CREATE SEQUENCE + DEFAULT nextval('seq_x')
--   DATETIME2(0)          -> TIMESTAMP
--   BIT / DEFAULT 1|0     -> BOOLEAN / DEFAULT true|false
--   VARCHAR(MAX)/NVARCHAR(MAX) -> VARCHAR (sem limite, DuckDB não distingue)
--   SYSUTCDATETIME()      -> DEFAULT now() (rede de segurança) + database.py
--                            passa :agora explicitamente (obter_agora_br())
--                            na maioria dos INSERTs -- SYSUTCDATETIME() era
--                            UTC-3 manual; now() aqui já é hora local da
--                            máquina (não precisa mais do ajuste -3)
--   fn_somente_digitos + fn_normalizar_telefone (2 funções T-SQL com
--   WHILE/BEGIN...END)    -> 1 CREATE MACRO só, usando regexp_replace nativo
--   OUTER APPLY (...)     -> LEFT JOIN LATERAL (...) ON true
--   TOP 1                 -> LIMIT 1
--   concatenação com '+'  -> '||'
--   CREATE NONCLUSTERED INDEX manual -> removido (FK já cria índice ART
--                            automático no DuckDB; ver seção "Restrições")
--   índice único filtrado (WHERE) -> removido (suporte incerto no DuckDB;
--                            a regra "1 responsável atual" já é garantida
--                            em Python, ver database.py)
--
-- LIMITAÇÃO REAL DO DUCKDB DESCOBERTA TESTANDO (2026-07-14): não dá pra
-- fazer UPDATE numa coluna que É uma FOREIGN KEY, numa linha que já tem
-- OUTRAS tabelas referenciando ela (o DuckDB reescreve UPDATE como
-- DELETE+INSERT por baixo dos panos, e o DELETE esfarra na FK de fora).
-- Por isso tb_dim_processo.tb_dim_id_status_mapfre_cod NÃO tem
-- "REFERENCES" aqui (é a única coluna que o robô atualiza depois da linha
-- já ter fila_envio/veículo/envolvido apontando pra ela) -- a integridade
-- continua garantida em Python (database.py sempre insere em
-- tb_dom_status_mapfre antes de gravar o ID). Ver comentário na própria
-- coluna, seção 2.
--
-- Rodar em ordem: 01_create_tables_duckdb.sql -> 02_insert_initial_data_duckdb.sql
-- =========================================================================

-- =========================================================================
-- 0. CAMADA BRUTA (DADOS CRUS DA MAPFRE)
-- =========================================================================
CREATE TABLE tb_bruto_processos_mapfre (
    tb_bruto_id_processo_cod BIGINT PRIMARY KEY,
    tb_bruto_no_sinistro VARCHAR(50),
    tb_bruto_json_completo VARCHAR NOT NULL,
    tb_bruto_data_captura TIMESTAMP DEFAULT now()
);

CREATE SEQUENCE seq_bruto_historico START 1;
CREATE TABLE tb_bruto_historico_processos_mapfre (
    tb_bruto_id_historico_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_bruto_historico'),
    tb_bruto_id_processo_cod INTEGER NOT NULL,
    tb_bruto_no_sinistro VARCHAR(50),
    tb_bruto_json_completo VARCHAR,
    tb_bruto_hash_json VARCHAR(64),
    tb_bruto_data_captura TIMESTAMP DEFAULT now()
);

-- =========================================================================
-- 1. TABELAS DE DOMÍNIO (DICIONÁRIOS)
-- =========================================================================
CREATE TABLE tb_dic_tipo_expediente (
    tb_dic_id_tipo_expediente_cod INTEGER PRIMARY KEY,
    tb_dic_sigla_expediente VARCHAR(5),
    tb_dic_desc_expediente VARCHAR(50),
    tb_dic_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dic_ativo BOOLEAN DEFAULT true
);

CREATE TABLE tb_dic_ddd_uf (
    tb_dic_ddd_cod INTEGER PRIMARY KEY,
    tb_dic_uf VARCHAR(2),
    tb_dic_nome_estado VARCHAR(50),
    tb_dic_regiao VARCHAR(20),
    tb_dic_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dic_ativo BOOLEAN DEFAULT true
);

CREATE TABLE tb_dic_status_fila (
    tb_dic_status_fila_cod INTEGER PRIMARY KEY,
    tb_dic_codigo_status VARCHAR(30),
    tb_dic_desc_status VARCHAR(100),
    tb_dic_requer_atencao BOOLEAN,
    tb_dic_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dic_ativo BOOLEAN DEFAULT true
);

CREATE TABLE tb_dom_tipo_envolvido (
    tb_dom_id_tipo_envolvido_cod INTEGER PRIMARY KEY,
    tb_dom_desc_tipo_envolvido VARCHAR(50),
    tb_dom_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dom_ativo BOOLEAN DEFAULT true
);

CREATE TABLE tb_dom_evento_fluxo (
    tb_dom_id_evento_mapfre_cod BIGINT PRIMARY KEY,
    tb_dom_desc_evento VARCHAR(200),
    tb_dom_fase_processo VARCHAR(50),
    tb_dom_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dom_ativo BOOLEAN DEFAULT true
);

CREATE TABLE tb_dom_status_evora (
    tb_dom_id_status_evora_cod INTEGER PRIMARY KEY,
    tb_dom_desc_status_evora VARCHAR(100) NOT NULL,
    tb_dom_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dom_ativo BOOLEAN DEFAULT true
);

CREATE TABLE tb_dom_status_mapfre (
    tb_dom_id_status_mapfre_cod INTEGER PRIMARY KEY,
    tb_dom_desc_status_mapfre VARCHAR(100),
    tb_dom_fl_status_final BOOLEAN,
    tb_dom_id_status_evora_cod INTEGER REFERENCES tb_dom_status_evora(tb_dom_id_status_evora_cod),
    tb_dom_contexto_mapfre VARCHAR(200),
    tb_dom_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dom_ativo BOOLEAN DEFAULT true
);

CREATE TABLE tb_dom_tipo_contato (
    tb_dom_id_tipo_contato_cod INTEGER PRIMARY KEY,
    tb_dom_desc_tipo_contato VARCHAR(20),
    tb_dom_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dom_ativo BOOLEAN DEFAULT true
);

-- =========================================================================
-- 2. TABELAS DE DIMENSÃO (CADASTROS BASE)
-- =========================================================================
CREATE TABLE tb_dim_usuario_robo (
    tb_dim_id_usuario_cod INTEGER PRIMARY KEY,
    tb_dim_nome_usuario VARCHAR(50),
    tb_dim_login_mapfre VARCHAR(100),
    tb_dim_email_usuario VARCHAR(150),
    tb_dim_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dim_ativo BOOLEAN DEFAULT true
);

CREATE TABLE tb_dim_processo (
    tb_dim_id_processo_cod BIGINT PRIMARY KEY,
    tb_dim_no_sinistro VARCHAR(50) NOT NULL,
    tb_dim_id_tipo_expediente_cod INTEGER REFERENCES tb_dic_tipo_expediente(tb_dic_id_tipo_expediente_cod),
    -- SEM "REFERENCES" de propósito (diferente do schema T-SQL, que tem FK aqui):
    -- essa é a única coluna de tb_dim_processo que o robô faz UPDATE depois da
    -- linha já ter outras tabelas referenciando ela (fila_envio, veiculo, etc.)
    -- -- e o DuckDB não permite UPDATE em coluna com FK nessas condições
    -- (reescreve como DELETE+INSERT internamente, o DELETE esbarra na FK de
    -- fora). A integridade continua garantida em Python: database.py sempre
    -- insere a linha em tb_dom_status_mapfre ANTES de gravar esse ID aqui.
    tb_dim_id_status_mapfre_cod INTEGER,
    tb_dim_uf_processo VARCHAR(2),
    tb_dim_nm_cia VARCHAR(100),
    tb_dim_dt_abertura_sinistro TIMESTAMP,
    tb_dim_dt_ocorrencia_sinistro TIMESTAMP,
    tb_dim_fase_processo VARCHAR(150),
    tb_dim_fl_alerta BOOLEAN,
    tb_dim_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dim_data_atualizacao TIMESTAMP,
    tb_dim_ativo BOOLEAN DEFAULT true
);
CREATE INDEX ix_dim_processo_no_sinistro ON tb_dim_processo (tb_dim_no_sinistro);

CREATE SEQUENCE seq_dim_veiculo START 1;
CREATE TABLE tb_dim_veiculo (
    tb_dim_id_veiculo_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_dim_veiculo'),
    tb_dim_id_processo_cod BIGINT REFERENCES tb_dim_processo(tb_dim_id_processo_cod),
    tb_dim_placa VARCHAR(10),
    tb_dim_chassi VARCHAR(50),
    tb_dim_marca VARCHAR(50),
    tb_dim_modelo VARCHAR(100),
    tb_dim_sub_modelo VARCHAR(150),
    tb_dim_ano_fabricacao INTEGER,
    tb_dim_valor_fipe DECIMAL(18,2),
    tb_dim_fl_alienado BOOLEAN,
    tb_dim_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dim_data_atualizacao TIMESTAMP,
    tb_dim_ativo BOOLEAN DEFAULT true
);

CREATE SEQUENCE seq_dim_envolvido START 1;
CREATE TABLE tb_dim_envolvido (
    tb_dim_id_envolvido_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_dim_envolvido'),
    tb_dim_id_processo_cod BIGINT REFERENCES tb_dim_processo(tb_dim_id_processo_cod),
    tb_dim_id_tipo_envolvido_cod INTEGER REFERENCES tb_dom_tipo_envolvido(tb_dom_id_tipo_envolvido_cod),
    tb_dim_nome VARCHAR(150),
    tb_dim_cpf_cnpj VARCHAR(20),
    tb_dim_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dim_ativo BOOLEAN DEFAULT true
);
CREATE INDEX ix_dim_envolvido_processo ON tb_dim_envolvido (tb_dim_id_processo_cod, tb_dim_id_tipo_envolvido_cod);

CREATE SEQUENCE seq_dim_contato START 1;
CREATE TABLE tb_dim_contato (
    tb_dim_id_contato_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_dim_contato'),
    tb_dim_id_envolvido_cod INTEGER REFERENCES tb_dim_envolvido(tb_dim_id_envolvido_cod),
    tb_dim_id_tipo_contato_cod INTEGER REFERENCES tb_dom_tipo_contato(tb_dom_id_tipo_contato_cod),
    tb_dim_ddd_cod INTEGER REFERENCES tb_dic_ddd_uf(tb_dic_ddd_cod),
    tb_dim_valor_contato VARCHAR(150),
    tb_dim_fl_principal BOOLEAN,
    tb_dim_data_cadastro TIMESTAMP DEFAULT now(),
    tb_dim_ativo BOOLEAN DEFAULT true
);
CREATE INDEX ix_dim_contato_envolvido ON tb_dim_contato (tb_dim_id_envolvido_cod, tb_dim_id_tipo_contato_cod);

-- =========================================================================
-- 3. TABELAS DE FATO (MOVIMENTAÇÕES, FILA E EVENTOS)
-- =========================================================================
CREATE SEQUENCE seq_fato_fila_envio START 1;
CREATE TABLE tb_fato_fila_envio (
    tb_fato_id_fila_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_fato_fila_envio'),
    tb_fato_id_processo_cod BIGINT REFERENCES tb_dim_processo(tb_dim_id_processo_cod),
    tb_fato_id_status_fila_cod INTEGER REFERENCES tb_dic_status_fila(tb_dic_status_fila_cod),
    tb_fato_tentativas INTEGER DEFAULT 0,
    tb_fato_data_hora_agendamento TIMESTAMP,
    tb_fato_data_ultima_tentativa TIMESTAMP,
    tb_fato_mensagem_erro VARCHAR,
    tb_fato_data_cadastro TIMESTAMP DEFAULT now(),
    tb_fato_data_atualizacao TIMESTAMP,
    tb_fato_ativo BOOLEAN DEFAULT true
);
CREATE INDEX ix_fato_fila_envio_status ON tb_fato_fila_envio (tb_fato_id_status_fila_cod, tb_fato_ativo);
CREATE INDEX ix_fato_fila_envio_processo ON tb_fato_fila_envio (tb_fato_id_processo_cod);

CREATE SEQUENCE seq_fato_acionamento START 1;
CREATE TABLE tb_fato_acionamento_sinistronet (
    tb_fato_id_acionamento_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_fato_acionamento'),
    tb_fato_id_processo_cod BIGINT REFERENCES tb_dim_processo(tb_dim_id_processo_cod),
    tb_fato_acionamento_id_api VARCHAR(100),
    tb_fato_status_sinistronet VARCHAR(50),
    tb_fato_hash_dados_processo VARCHAR(64),
    tb_fato_data_ultima_sincronizacao TIMESTAMP,
    tb_fato_data_cadastro TIMESTAMP DEFAULT now()
);

CREATE SEQUENCE seq_fato_fluxo_mapfre START 1;
CREATE TABLE tb_fato_fluxo_mapfre (
    tb_fato_id_fluxo_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_fato_fluxo_mapfre'),
    tb_fato_id_processo_cod BIGINT REFERENCES tb_dim_processo(tb_dim_id_processo_cod),
    tb_fato_id_evento_mapfre_cod BIGINT REFERENCES tb_dom_evento_fluxo(tb_dom_id_evento_mapfre_cod),
    tb_fato_descricao_complementar VARCHAR,
    tb_fato_data_hora_evento TIMESTAMP,
    tb_fato_data_cadastro TIMESTAMP DEFAULT now()
);

CREATE SEQUENCE seq_fato_fluxo_etapa START 1;
CREATE TABLE tb_fato_fluxo_etapa (
    tb_fato_id_fluxo_etapa_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_fato_fluxo_etapa'),
    tb_fato_id_processo_cod BIGINT REFERENCES tb_dim_processo(tb_dim_id_processo_cod),
    tb_fato_id_tarefa_cod BIGINT,
    tb_fato_nome_tarefa VARCHAR(200),
    tb_fato_status_tarefa VARCHAR(50),
    tb_fato_data_hora_etapa TIMESTAMP,
    tb_fato_data_cadastro TIMESTAMP DEFAULT now()
);

CREATE SEQUENCE seq_fato_documento START 1;
CREATE TABLE tb_fato_documento (
    tb_fato_id_doc_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_fato_documento'),
    tb_fato_id_processo_cod BIGINT REFERENCES tb_dim_processo(tb_dim_id_processo_cod),
    tb_fato_nome_documento VARCHAR(200),
    tb_fato_status_documento VARCHAR(50),
    tb_fato_data_saida TIMESTAMP,
    tb_fato_data_cadastro TIMESTAMP DEFAULT now(),
    tb_fato_data_atualizacao TIMESTAMP
);

CREATE SEQUENCE seq_fato_sla START 1;
CREATE TABLE tb_fato_sla_processo (
    tb_fato_id_sla_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_fato_sla'),
    tb_fato_id_processo_cod BIGINT REFERENCES tb_dim_processo(tb_dim_id_processo_cod),
    tb_fato_data_recepcao_mapfre TIMESTAMP,
    tb_fato_data_captura_robo TIMESTAMP,
    tb_fato_data_envio_sinistronet TIMESTAMP,
    tb_fato_tempo_fila_minutos INTEGER,
    tb_fato_status_sla VARCHAR(50),
    tb_fato_data_cadastro TIMESTAMP DEFAULT now()
);

CREATE SEQUENCE seq_fato_hist_usuario START 1;
CREATE TABLE tb_fato_historico_usuario_processo (
    tb_fato_id_historico_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_fato_hist_usuario'),
    tb_fato_id_processo_cod BIGINT REFERENCES tb_dim_processo(tb_dim_id_processo_cod),
    tb_fato_id_usuario_cod INTEGER REFERENCES tb_dim_usuario_robo(tb_dim_id_usuario_cod),
    tb_fato_data_entrada TIMESTAMP NOT NULL DEFAULT now(),
    tb_fato_data_saida TIMESTAMP,
    tb_fato_fl_responsavel_atual BOOLEAN DEFAULT true
);
-- A regra "so 1 responsavel atual por processo" (antes um indice unico
-- filtrado no T-SQL) fica garantida em Python (database.py sempre zera o
-- fl_responsavel_atual anterior antes de inserir o novo) -- suporte a
-- indice parcial/filtrado no DuckDB nao e claro na documentacao atual.
CREATE INDEX ix_fato_hist_usuario_processo ON tb_fato_historico_usuario_processo (tb_fato_id_processo_cod);

CREATE SEQUENCE seq_fato_transferencia START 1;
CREATE TABLE tb_fato_transferencia_processo (
    tb_fato_id_transferencia_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_fato_transferencia'),
    tb_fato_id_processo_cod BIGINT REFERENCES tb_dim_processo(tb_dim_id_processo_cod),
    tb_fato_id_usuario_origem_cod INTEGER REFERENCES tb_dim_usuario_robo(tb_dim_id_usuario_cod),
    tb_fato_id_usuario_destino_cod INTEGER REFERENCES tb_dim_usuario_robo(tb_dim_id_usuario_cod),
    tb_fato_data_hora_transferencia TIMESTAMP DEFAULT now(),
    tb_fato_tipo_movimentacao VARCHAR(50)
);

-- =========================================================================
-- 4. CONFIGURAÇÕES GLOBAIS E LOGS (GOVERNANÇA)
-- =========================================================================
CREATE SEQUENCE seq_config_parametro START 1;
CREATE TABLE tb_config_parametros_robo (
    tb_config_id_parametro_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_config_parametro'),
    tb_config_chave_parametro VARCHAR(100) UNIQUE,
    tb_config_valor_texto VARCHAR(500),
    tb_config_valor_numero DOUBLE,
    tb_config_tipo_dado VARCHAR(20),
    tb_config_descricao VARCHAR(255),
    tb_config_data_ultima_alteracao TIMESTAMP DEFAULT now(),
    tb_config_usuario_alteracao VARCHAR(50)
);

-- ATENÇÃO (item pendente #1 - SEGURANÇA, herdado do schema T-SQL):
-- tb_config_senha_usuario e tb_config_segredo_cliente ficam em TEXTO PLANO.
-- Ver sql/01_create_tables.sql para a nota completa.
CREATE SEQUENCE seq_config_credencial START 1;
CREATE TABLE tb_config_credenciais (
    tb_config_id_credencial_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_config_credencial'),
    tb_config_sistema VARCHAR(50),
    tb_config_login_usuario VARCHAR(100) NOT NULL,
    tb_config_senha_usuario VARCHAR(255) NOT NULL,
    tb_config_nome_responsavel VARCHAR(100),
    tb_config_data_ultima_atualizacao TIMESTAMP DEFAULT now(),
    tb_config_atualizado_por VARCHAR(100),
    tb_config_ativo BOOLEAN DEFAULT true
);

CREATE SEQUENCE seq_config_api_sinistronet START 1;
CREATE TABLE tb_config_api_sinistronet (
    tb_config_id_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_config_api_sinistronet'),
    tb_config_base_url VARCHAR(500),
    tb_config_id_cliente VARCHAR(200),
    tb_config_segredo_cliente VARCHAR(500),
    tb_config_tempo_limite INTEGER,
    tb_config_data_atualizacao TIMESTAMP DEFAULT now(),
    tb_config_ativo BOOLEAN DEFAULT true
);

-- Acesso direto (SQL) ao banco do Sinistro.net, separado da API REST acima.
-- Usado pra consultar views como Tb_VwEstoqueCompleto (processos já
-- cadastrados lá), fora do escopo da API de acionamento.
CREATE SEQUENCE seq_config_banco_sinistronet START 1;
CREATE TABLE tb_config_banco_sinistronet (
    tb_config_id_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_config_banco_sinistronet'),
    tb_config_servidor VARCHAR(200),
    tb_config_banco VARCHAR(100),
    tb_config_usuario VARCHAR(100),
    tb_config_senha VARCHAR(500),
    tb_config_data_atualizacao TIMESTAMP DEFAULT now(),
    tb_config_ativo BOOLEAN DEFAULT true
);

-- Cache diário da Tb_VwEstoqueCompleto (Sinistro.net é D-1, então só vale a
-- pena consultar 1x por dia -- ver conciliar_fila_com_sinistronet() em
-- database.py). Toda execução do dia reaproveita esse snapshot; só é
-- atualizado de novo quando tb_cache_data_snapshot não é mais hoje.
CREATE TABLE tb_cache_estoque_sinistronet (
    tb_cache_sinistro VARCHAR(50),
    tb_cache_data_snapshot DATE
);

CREATE SEQUENCE seq_log_auditoria_cred START 1;
CREATE TABLE tb_log_auditoria_credenciais (
    tb_log_id_log_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_log_auditoria_cred'),
    tb_log_sistema VARCHAR(50),
    tb_log_login_usuario VARCHAR(100),
    tb_log_acao_realizada VARCHAR(50),
    tb_log_quem_alterou VARCHAR(100),
    tb_log_data_hora_alteracao TIMESTAMP DEFAULT now()
);

CREATE TABLE tb_log_execucao_robo (
    tb_log_execution_id_cod VARCHAR(50) PRIMARY KEY,
    tb_log_data_inicio TIMESTAMP,
    tb_log_data_fim TIMESTAMP,
    tb_log_status_execucao VARCHAR(20),
    tb_log_qtd_processos_lidos INTEGER,
    tb_log_qtd_novos_processos INTEGER,
    tb_log_mensagem_geral VARCHAR
);

CREATE SEQUENCE seq_log_transacao START 1;
CREATE TABLE tb_log_transacao_api (
    tb_log_id_transacao_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_log_transacao'),
    tb_log_execution_id_cod VARCHAR(50) REFERENCES tb_log_execucao_robo(tb_log_execution_id_cod),
    tb_log_id_processo_cod BIGINT REFERENCES tb_dim_processo(tb_dim_id_processo_cod),
    tb_log_sistema_destino VARCHAR(50),
    tb_log_tipo_acao VARCHAR(50),
    tb_log_status_code INTEGER,
    tb_log_payload_enviado VARCHAR,
    tb_log_resposta_recebida VARCHAR,
    tb_log_data_hora_transacao TIMESTAMP DEFAULT now()
);
CREATE INDEX ix_log_transacao_processo ON tb_log_transacao_api (tb_log_id_processo_cod);
CREATE INDEX ix_log_transacao_execution ON tb_log_transacao_api (tb_log_execution_id_cod);

CREATE SEQUENCE seq_log_notificacao START 1;
CREATE TABLE tb_log_notificacao_power_automate (
    tb_log_id_notificacao_cod INTEGER PRIMARY KEY DEFAULT nextval('seq_log_notificacao'),
    tb_log_execution_id_cod VARCHAR(50) REFERENCES tb_log_execucao_robo(tb_log_execution_id_cod),
    tb_log_id_processo_cod BIGINT REFERENCES tb_dim_processo(tb_dim_id_processo_cod),
    tb_log_tipo_notificacao VARCHAR(50) DEFAULT 'email_acionamento',
    tb_log_status_code INTEGER,
    tb_log_payload_enviado VARCHAR,
    tb_log_mensagem_retorno VARCHAR,
    tb_log_data_hora_disparo TIMESTAMP DEFAULT now()
);
CREATE INDEX ix_log_notificacao_processo ON tb_log_notificacao_power_automate (tb_log_id_processo_cod);

-- (tb_log_anomalia_negocio removida em 2026-07-15 -- schema definido mas
-- nenhum código nunca gravou nela; ver DOCUMENTACAO_PROJETO.md)

-- =========================================================================
-- 4.1 MACRO (normalização de telefone) — substitui as 2 funções T-SQL
-- (fn_somente_digitos + fn_normalizar_telefone) por 1 macro só, usando
-- regexp_replace nativo do DuckDB em vez do loop WHILE/PATINDEX do T-SQL.
-- Mesma regra (ver sql/01_create_tables.sql §4.1 para o raciocínio completo
-- e os números da análise de 2026-07-13): só aceita 8-9 dígitos, nunca
-- tenta recortar DDD do telefone (a Mapfre sempre manda DDD separado).
-- =========================================================================
CREATE OR REPLACE MACRO fn_normalizar_telefone(valor) AS (
    CASE WHEN LENGTH(regexp_replace(COALESCE(valor, ''), '[^0-9]', '', 'g')) IN (8, 9)
         THEN regexp_replace(valor, '[^0-9]', '', 'g')
         ELSE NULL END
);

-- =========================================================================
-- 5. VIEWS (mesma lógica das views em sql/01_create_tables.sql; OUTER APPLY
--    virou LEFT JOIN LATERAL ... ON true, TOP 1 virou LIMIT 1, '+' de
--    concatenação virou '||')
-- =========================================================================
CREATE OR REPLACE VIEW vw_processos_prontos_envio AS
WITH trc_num AS (
    -- 2026-07-30: numera terceiros (TRC) por sinistro -- 1o = 'T', 2o = 'T2', 3o = 'T3'...
    -- Antes usava 'T' fixo pra todos, o que colidia quando havia 2+ terceiros no
    -- mesmo sinistro (o 2o batia 409 achando duplicata do 1o -- 5 casos reais
    -- confirmados em producao antes desse fix).
    SELECT
        p.tb_dim_id_processo_cod,
        ROW_NUMBER() OVER (
            PARTITION BY p.tb_dim_no_sinistro
            ORDER BY p.tb_dim_id_processo_cod
        ) AS rn_trc
    FROM tb_dim_processo p
    LEFT JOIN tb_dic_tipo_expediente de ON p.tb_dim_id_tipo_expediente_cod = de.tb_dic_id_tipo_expediente_cod
    WHERE de.tb_dic_sigla_expediente = 'TRC' AND p.tb_dim_ativo = true
)
SELECT
    f.tb_fato_id_fila_cod AS id_fila,
    p.tb_dim_id_processo_cod AS id_processo,
    p.tb_dim_nm_cia AS cia,
    p.tb_dim_uf_processo AS uf_processo,
    CASE
        WHEN de.tb_dic_sigla_expediente = 'TRC' THEN
            p.tb_dim_no_sinistro || 'T' || CASE WHEN tn.rn_trc > 1 THEN CAST(tn.rn_trc AS VARCHAR) ELSE '' END
        ELSE p.tb_dim_no_sinistro
    END AS sinistro_tratado,

    p.tb_dim_fase_processo AS fase_processo_site,
    se.tb_dom_id_status_evora_cod AS id_status_evora,
    se.tb_dom_desc_status_evora AS desc_status_oficial_evora,
    p.tb_dim_id_status_mapfre_cod AS id_status_mapfre_original,
    sm.tb_dom_desc_status_mapfre AS desc_status_mapfre_original,
    sm.tb_dom_contexto_mapfre AS contexto_mapfre,
    p.tb_dim_fl_alerta AS alerta_processo,
    env.tb_dim_id_tipo_envolvido_cod AS tipo_envolvido_id,
    LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(env.tb_dim_nome, '  ', ' ' || chr(7)), chr(7) || ' ', ''), chr(7), ''))) AS nome_segurado,
    COALESCE(NULLIF(con_email.tb_dim_valor_contato, ''), 'nao_informado@segurado.com') AS email_segurado,
    con_tel.tb_dim_ddd_cod AS ddd_segurado,
    fn_normalizar_telefone(con_tel.tb_dim_valor_contato) AS tel_segurado,
    CASE WHEN LENGTH(REPLACE(env.tb_dim_cpf_cnpj, '.0', '')) <= 11 THEN 1 ELSE 2 END AS tipo_doc_id,
    CASE WHEN LENGTH(REPLACE(env.tb_dim_cpf_cnpj, '.0', '')) <= 11
         THEN RIGHT('00000000000' || REPLACE(env.tb_dim_cpf_cnpj, '.0', ''), 11)
         ELSE RIGHT('00000000000000' || REPLACE(env.tb_dim_cpf_cnpj, '.0', ''), 14)
    END AS doc_formatado,
    env_corr.tb_dim_nome AS nome_corretor,
    con_corr_email.tb_dim_valor_contato AS email_corretor,
    con_corr_tel.tb_dim_ddd_cod AS ddd_corretor,
    fn_normalizar_telefone(con_corr_tel.tb_dim_valor_contato) AS tel_corretor,
    env_ana_mapfre.tb_dim_nome AS nome_analista_mapfre,
    con_ana_email.tb_dim_valor_contato AS email_analista_mapfre,
    u.tb_dim_nome_usuario AS nome_analista_evora,
    u.tb_dim_email_usuario AS email_analista_evora,
    p.tb_dim_dt_ocorrencia_sinistro AS dt_sinistro,
    p.tb_dim_dt_abertura_sinistro AS data_mapfre,
    v.tb_dim_placa AS placa_veiculo,
    v.tb_dim_chassi AS chassi_veiculo,
    v.tb_dim_marca AS marca_veiculo,
    v.tb_dim_modelo AS modelo_veiculo,
    v.tb_dim_sub_modelo AS sub_modelo_veiculo,
    v.tb_dim_ano_fabricacao AS ano_fabricacao,
    v.tb_dim_fl_alienado AS veiculo_alienado,
    v.tb_dim_valor_fipe AS valor_fipe,
    f.tb_fato_data_hora_agendamento AS data_agendada
FROM tb_fato_fila_envio f
JOIN tb_dim_processo p ON f.tb_fato_id_processo_cod = p.tb_dim_id_processo_cod
LEFT JOIN trc_num tn ON tn.tb_dim_id_processo_cod = p.tb_dim_id_processo_cod
LEFT JOIN tb_dic_tipo_expediente de ON p.tb_dim_id_tipo_expediente_cod = de.tb_dic_id_tipo_expediente_cod
LEFT JOIN tb_dom_status_mapfre sm ON p.tb_dim_id_status_mapfre_cod = sm.tb_dom_id_status_mapfre_cod
LEFT JOIN tb_dom_status_evora se ON sm.tb_dom_id_status_evora_cod = se.tb_dom_id_status_evora_cod
LEFT JOIN (
    SELECT tb_fato_id_processo_cod, MAX(tb_fato_id_usuario_cod) AS id_usuario
    FROM tb_fato_historico_usuario_processo
    GROUP BY tb_fato_id_processo_cod
) hist ON p.tb_dim_id_processo_cod = hist.tb_fato_id_processo_cod
LEFT JOIN tb_dim_usuario_robo u ON hist.id_usuario = u.tb_dim_id_usuario_cod
LEFT JOIN tb_dim_envolvido env_ana_mapfre ON p.tb_dim_id_processo_cod = env_ana_mapfre.tb_dim_id_processo_cod AND env_ana_mapfre.tb_dim_id_tipo_envolvido_cod = 4
LEFT JOIN LATERAL (SELECT tb_dim_valor_contato FROM tb_dim_contato WHERE tb_dim_id_envolvido_cod = env_ana_mapfre.tb_dim_id_envolvido_cod AND tb_dim_id_tipo_contato_cod = 3 ORDER BY tb_dim_fl_principal DESC LIMIT 1) AS con_ana_email ON true
LEFT JOIN tb_dim_envolvido env ON p.tb_dim_id_processo_cod = env.tb_dim_id_processo_cod AND env.tb_dim_id_tipo_envolvido_cod IN (1, 2)
LEFT JOIN LATERAL (SELECT tb_dim_valor_contato FROM tb_dim_contato WHERE tb_dim_id_envolvido_cod = env.tb_dim_id_envolvido_cod AND tb_dim_id_tipo_contato_cod = 3 ORDER BY tb_dim_fl_principal DESC LIMIT 1) AS con_email ON true
LEFT JOIN LATERAL (SELECT tb_dim_ddd_cod, tb_dim_valor_contato FROM tb_dim_contato WHERE tb_dim_id_envolvido_cod = env.tb_dim_id_envolvido_cod AND tb_dim_id_tipo_contato_cod = 2 ORDER BY tb_dim_fl_principal DESC LIMIT 1) AS con_tel ON true
LEFT JOIN tb_dim_envolvido env_corr ON p.tb_dim_id_processo_cod = env_corr.tb_dim_id_processo_cod AND env_corr.tb_dim_id_tipo_envolvido_cod = 3
LEFT JOIN LATERAL (SELECT tb_dim_valor_contato FROM tb_dim_contato WHERE tb_dim_id_envolvido_cod = env_corr.tb_dim_id_envolvido_cod AND tb_dim_id_tipo_contato_cod = 3 ORDER BY tb_dim_fl_principal DESC LIMIT 1) AS con_corr_email ON true
LEFT JOIN LATERAL (SELECT tb_dim_ddd_cod, tb_dim_valor_contato FROM tb_dim_contato WHERE tb_dim_id_envolvido_cod = env_corr.tb_dim_id_envolvido_cod AND tb_dim_id_tipo_contato_cod = 2 ORDER BY tb_dim_fl_principal DESC LIMIT 1) AS con_corr_tel ON true
LEFT JOIN tb_dim_veiculo v ON p.tb_dim_id_processo_cod = v.tb_dim_id_processo_cod
WHERE f.tb_fato_id_status_fila_cod IN (1, 3) AND f.tb_fato_ativo = true
  -- 2026-07-30: protecao extra contra reativacao manual indevida de fila --
  -- nunca reoferecer pra envio um processo que a Auditoria (ou qualquer
  -- checagem) ja confirmou FINALIZADO (22) ou CANCELADO (98) na Mapfre,
  -- mesmo que tb_fato_ativo volte a True por engano.
  AND (p.tb_dim_id_status_mapfre_cod IS NULL OR p.tb_dim_id_status_mapfre_cod NOT IN (22, 98));

CREATE OR REPLACE VIEW vw_historico_geral_processos AS
SELECT
    p.tb_dim_id_processo_cod AS id_processo,
    CASE WHEN de.tb_dic_sigla_expediente = 'TRC' THEN p.tb_dim_no_sinistro || 'T' ELSE p.tb_dim_no_sinistro END AS sinistro_tratado,
    p.tb_dim_no_sinistro AS numero_sinistro_original,
    p.tb_dim_nm_cia AS cia,
    p.tb_dim_uf_processo AS uf_processo,
    de.tb_dic_desc_expediente AS tipo_expediente,
    p.tb_dim_fase_processo AS fase_processo_site,
    p.tb_dim_fl_alerta AS alerta_processo,
    se.tb_dom_desc_status_evora AS status_oficial_evora,
    sm.tb_dom_desc_status_mapfre AS status_mapfre_original,
    sf.tb_dic_codigo_status AS status_robo,
    fe.tb_fato_mensagem_erro AS mensagem_robo_api,
    p.tb_dim_dt_abertura_sinistro AS data_abertura_sinistro,
    p.tb_dim_dt_ocorrencia_sinistro AS data_ocorrencia_sinistro,
    sla.tb_fato_data_captura_robo AS data_capturado_site,
    sla.tb_fato_data_envio_sinistronet AS data_cadastrado_sinistronet,
    hist.data_saida AS data_saida_fila_mapfre,
    ult_alt.ultima_alteracao_site AS data_ultima_mudanca_site,
    u.tb_dim_nome_usuario AS analista_evora,
    env_ana_mapfre.tb_dim_nome AS analista_mapfre,
    con_ana_email.tb_dim_valor_contato AS email_analista_mapfre,
    te.tb_dom_desc_tipo_envolvido AS papel_envolvido,
    LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(env.tb_dim_nome, '  ', ' ' || chr(7)), chr(7) || ' ', ''), chr(7), ''))) AS nome_segurado_terceiro,
    CASE WHEN LENGTH(REPLACE(env.tb_dim_cpf_cnpj, '.0', '')) <= 11
         THEN RIGHT('00000000000' || REPLACE(env.tb_dim_cpf_cnpj, '.0', ''), 11)
         ELSE RIGHT('00000000000000' || REPLACE(env.tb_dim_cpf_cnpj, '.0', ''), 14)
    END AS documento_segurado_terceiro,
    con_email.tb_dim_valor_contato AS email_segurado_terceiro,
    CAST(con_tel.tb_dim_ddd_cod AS VARCHAR) || fn_normalizar_telefone(con_tel.tb_dim_valor_contato) AS telefone_segurado_terceiro,
    env_corr.tb_dim_nome AS nome_corretor,
    con_corr_email.tb_dim_valor_contato AS email_corretor,
    CAST(con_corr_tel.tb_dim_ddd_cod AS VARCHAR) || fn_normalizar_telefone(con_corr_tel.tb_dim_valor_contato) AS telefone_corretor,
    v.tb_dim_placa AS placa_veiculo,
    v.tb_dim_chassi AS chassi_veiculo,
    v.tb_dim_marca AS marca_veiculo,
    v.tb_dim_modelo AS modelo_veiculo,
    v.tb_dim_sub_modelo AS sub_modelo_veiculo,
    v.tb_dim_ano_fabricacao AS ano_fabricacao,
    v.tb_dim_fl_alienado AS veiculo_alienado,
    v.tb_dim_valor_fipe AS valor_fipe
FROM tb_dim_processo p
LEFT JOIN tb_dic_tipo_expediente de ON p.tb_dim_id_tipo_expediente_cod = de.tb_dic_id_tipo_expediente_cod
LEFT JOIN tb_dom_status_mapfre sm ON p.tb_dim_id_status_mapfre_cod = sm.tb_dom_id_status_mapfre_cod
LEFT JOIN tb_dom_status_evora se ON sm.tb_dom_id_status_evora_cod = se.tb_dom_id_status_evora_cod
LEFT JOIN tb_fato_fila_envio fe ON p.tb_dim_id_processo_cod = fe.tb_fato_id_processo_cod
LEFT JOIN tb_dic_status_fila sf ON fe.tb_fato_id_status_fila_cod = sf.tb_dic_status_fila_cod
LEFT JOIN tb_fato_sla_processo sla ON p.tb_dim_id_processo_cod = sla.tb_fato_id_processo_cod
LEFT JOIN tb_dim_veiculo v ON p.tb_dim_id_processo_cod = v.tb_dim_id_processo_cod
LEFT JOIN (
    SELECT
        tb_fato_id_processo_cod,
        MAX(tb_fato_id_usuario_cod) AS id_usuario,
        MAX(tb_fato_data_saida) AS data_saida
    FROM tb_fato_historico_usuario_processo
    GROUP BY tb_fato_id_processo_cod
) hist ON p.tb_dim_id_processo_cod = hist.tb_fato_id_processo_cod
LEFT JOIN tb_dim_usuario_robo u ON hist.id_usuario = u.tb_dim_id_usuario_cod
LEFT JOIN LATERAL (
    SELECT MAX(dt) AS ultima_alteracao_site
    FROM (
        SELECT tb_dim_data_cadastro AS dt FROM tb_dim_processo WHERE tb_dim_id_processo_cod = p.tb_dim_id_processo_cod
        UNION ALL
        SELECT MAX(tb_fato_data_cadastro) FROM tb_fato_fluxo_mapfre WHERE tb_fato_id_processo_cod = p.tb_dim_id_processo_cod
        UNION ALL
        SELECT MAX(tb_fato_data_cadastro) FROM tb_fato_fluxo_etapa WHERE tb_fato_id_processo_cod = p.tb_dim_id_processo_cod
    ) AS datas
) AS ult_alt ON true
LEFT JOIN tb_dim_envolvido env_ana_mapfre ON p.tb_dim_id_processo_cod = env_ana_mapfre.tb_dim_id_processo_cod AND env_ana_mapfre.tb_dim_id_tipo_envolvido_cod = 4
LEFT JOIN LATERAL (SELECT tb_dim_valor_contato FROM tb_dim_contato WHERE tb_dim_id_envolvido_cod = env_ana_mapfre.tb_dim_id_envolvido_cod AND tb_dim_id_tipo_contato_cod = 3 ORDER BY tb_dim_fl_principal DESC LIMIT 1) AS con_ana_email ON true
LEFT JOIN tb_dim_envolvido env ON p.tb_dim_id_processo_cod = env.tb_dim_id_processo_cod AND env.tb_dim_id_tipo_envolvido_cod IN (1, 2)
LEFT JOIN tb_dom_tipo_envolvido te ON env.tb_dim_id_tipo_envolvido_cod = te.tb_dom_id_tipo_envolvido_cod
LEFT JOIN LATERAL (SELECT tb_dim_valor_contato FROM tb_dim_contato WHERE tb_dim_id_envolvido_cod = env.tb_dim_id_envolvido_cod AND tb_dim_id_tipo_contato_cod = 3 ORDER BY tb_dim_fl_principal DESC LIMIT 1) AS con_email ON true
LEFT JOIN LATERAL (SELECT tb_dim_ddd_cod, tb_dim_valor_contato FROM tb_dim_contato WHERE tb_dim_id_envolvido_cod = env.tb_dim_id_envolvido_cod AND tb_dim_id_tipo_contato_cod = 2 ORDER BY tb_dim_fl_principal DESC LIMIT 1) AS con_tel ON true
LEFT JOIN tb_dim_envolvido env_corr ON p.tb_dim_id_processo_cod = env_corr.tb_dim_id_processo_cod AND env_corr.tb_dim_id_tipo_envolvido_cod = 3
LEFT JOIN LATERAL (SELECT tb_dim_valor_contato FROM tb_dim_contato WHERE tb_dim_id_envolvido_cod = env_corr.tb_dim_id_envolvido_cod AND tb_dim_id_tipo_contato_cod = 3 ORDER BY tb_dim_fl_principal DESC LIMIT 1) AS con_corr_email ON true
LEFT JOIN LATERAL (SELECT tb_dim_ddd_cod, tb_dim_valor_contato FROM tb_dim_contato WHERE tb_dim_id_envolvido_cod = env_corr.tb_dim_id_envolvido_cod AND tb_dim_id_tipo_contato_cod = 2 ORDER BY tb_dim_fl_principal DESC LIMIT 1) AS con_corr_tel ON true;

-- =========================================================================
-- RESTRIÇÕES CONFIRMADAS (verificadas na documentação oficial do DuckDB
-- durante o planejamento desta migração, 2026-07-13):
-- - Single-writer: só 1 processo escreve no arquivo por vez (lock de SO).
--   OK pro uso atual (robô roda agendado, execução única por vez).
-- - FOREIGN KEY com ON DELETE CASCADE não é suportado -- não era usado
--   neste schema mesmo, não afeta nada.
-- - FK cria índice ART automático -- por isso os índices manuais que
--   existiam em cima de toda FK no schema T-SQL (sql/01_create_tables.sql)
--   foram removidos aqui, ficariam redundantes.
-- =========================================================================
