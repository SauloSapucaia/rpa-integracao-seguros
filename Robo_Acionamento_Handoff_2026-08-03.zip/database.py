import pandas as pd
import re
import json
import hashlib
import warnings
import pyodbc
import os
from sqlalchemy import create_engine, text
from funcoes_auxiliares import tratar_valor_fipe, obter_agora_br, gerar_placa_placeholder
from config import DUCKDB_PATH

# Variável global para guardar a engine e evitar reconexões repetidas
_engine_cache = None

def obter_engine():
    """Retorna a engine existente ou cria uma nova se for a primeira vez.

    Migrado de SQL Server/Fabric para DuckDB em 2026-07-13 (ver
    DOCUMENTACAO_PROJETO.md): TI não disponibiliza banco, Azure bloqueado
    pelo tenant, e o usuário não tem direitos de administrador nesta
    máquina -- então precisava de um motor embutido, sem servidor, sem
    admin. DuckDB é biblioteca Python pura.
    """
    global _engine_cache
    if _engine_cache is not None:
        return _engine_cache
    _engine_cache = create_engine(f"duckdb:///{DUCKDB_PATH}")
    return _engine_cache

# =========================================================================
# FUNÇÕES DE CARREGAMENTO (READ)
# =========================================================================

def carregar_credenciais_mapfre():
    """Busca os logins ativos direto da tabela tb_config_credenciais."""
    engine = obter_engine()
    query = """
        SELECT tb_config_login_usuario, tb_config_senha_usuario, tb_config_nome_responsavel
        FROM tb_config_credenciais
        WHERE tb_config_sistema = 'Mapfre' AND tb_config_ativo = true
    """
    df_creds = pd.read_sql(query, engine)

    return {
        row['tb_config_nome_responsavel']: {
            "login": row['tb_config_login_usuario'],
            "senha": row['tb_config_senha_usuario']
        } for _, row in df_creds.iterrows()
    }

CAMINHO_PLANILHA_SENHAS = r"M:\8_Sinistro\Mapfre\Controle_Senhas_Mapfre.xlsx"

def sincronizar_senhas_planilha():
    """
    Lê a planilha de controle de senhas no M:\\ (compartilhamento que o robô já
    acessa sem permissão nova) e aplica em tb_config_credenciais qualquer senha
    diferente da que está no banco -- assim, quem troca a senha na planilha não
    depende de ninguém rodar nada na mão, a próxima execução (no máx. 2h depois)
    já aplica sozinha. Chamada logo no Passo 1, antes de carregar as credenciais,
    pra a própria execução atual já usar a senha nova se ela tiver mudado.
    """
    if not os.path.exists(CAMINHO_PLANILHA_SENHAS):
        print(f" -> Aviso: planilha de controle de senhas não encontrada em {CAMINHO_PLANILHA_SENHAS}. Pulando sincronização.")
        return 0

    try:
        df_planilha = pd.read_excel(CAMINHO_PLANILHA_SENHAS)
    except Exception as e:
        print(f" -> Aviso: falha ao ler a planilha de controle de senhas ({e}). Pulando sincronização.")
        return 0

    engine = obter_engine()
    agora = obter_agora_br()
    atualizados = 0

    with engine.begin() as conn:
        for _, row in df_planilha.iterrows():
            conta = str(row.get('Conta', '')).strip()
            senha_planilha = str(row.get('Senha', '')).strip()
            if not conta or not senha_planilha or senha_planilha.lower() == 'nan':
                continue

            atual = conn.execute(text("""
                SELECT tb_config_senha_usuario FROM tb_config_credenciais
                WHERE tb_config_sistema = 'Mapfre' AND tb_config_nome_responsavel = :conta AND tb_config_ativo = true
            """), {"conta": conta}).fetchone()

            if atual and atual[0] != senha_planilha:
                conn.execute(text("""
                    UPDATE tb_config_credenciais
                    SET tb_config_senha_usuario = :senha,
                        tb_config_data_ultima_atualizacao = :agora,
                        tb_config_atualizado_por = 'Planilha Controle_Senhas_Mapfre.xlsx'
                    WHERE tb_config_sistema = 'Mapfre' AND tb_config_nome_responsavel = :conta AND tb_config_ativo = true
                """), {"senha": senha_planilha, "agora": agora, "conta": conta})
                atualizados += 1
                print(f" -> Senha da conta {conta} atualizada automaticamente via planilha de controle.")

    return atualizados

def carregar_mapa_ddd():
    """Busca a tabela de DDDs e UFs do banco para validação no robô."""
    engine = obter_engine()
    query = "SELECT tb_dic_ddd_cod, tb_dic_uf FROM tb_dic_ddd_uf WHERE tb_dic_ativo = true"
    df_ddd = pd.read_sql(query, engine)
    return dict(zip(df_ddd['tb_dic_ddd_cod'], df_ddd['tb_dic_uf']))

def carregar_parametros_robo():
    """Busca configurações dinâmicas da tabela de parâmetros respeitando a tipagem real do Banco."""
    engine = obter_engine()
    # Puxamos as duas colunas novas do banco
    query = "SELECT tb_config_chave_parametro, tb_config_valor_texto, tb_config_valor_numero FROM tb_config_parametros_robo"
    df_params = pd.read_sql(query, engine)

    parametros = {}
    for _, row in df_params.iterrows():
        chave = row['tb_config_chave_parametro']

        # Se a coluna numérica não for nula, o Python já absorve como INT (número real)
        if pd.notna(row['tb_config_valor_numero']):
            parametros[chave] = int(row['tb_config_valor_numero'])
        else:
            # Caso contrário, absorve como String (texto)
            parametros[chave] = row['tb_config_valor_texto']

    return parametros

def higienizar_telefone(telefone_bruto, ddd_bruto=None):
    """
    Aplica as regras A, B e C para higienizar contatos antes de salvar no banco.
    """
    if pd.isna(telefone_bruto) or str(telefone_bruto).lower() in ['nan', 'none', '']:
        return None, None

    # PASSO A: Remove tudo que NÃO for número (letras, parênteses, traços, espaços)
    tel_limpo = re.sub(r'\D', '', str(telefone_bruto))

    # PASSO C: Exclui sujeiras irrecuperáveis (< 8 dígitos)
    if len(tel_limpo) < 8:
        return None, None

    # PASSO B: Se tem 10 ou 11 dígitos e não temos DDD separado, fatiamos o número
    if len(tel_limpo) in (10, 11) and not ddd_bruto:
        ddd_final = int(tel_limpo[:2])
        tel_final = tel_limpo[2:]
        return ddd_final, tel_final

    # Se já tem DDD, apenas limpa e devolve
    ddd_final = int(str(ddd_bruto).replace('.0', '').strip()) if ddd_bruto and str(ddd_bruto).replace('.0', '').strip().isdigit() else None
    return ddd_final, tel_limpo

def carregar_config_sinistronet():
    """Busca as configurações exclusivas da API Sinistro.net na tabela dedicada."""
    engine = obter_engine()
    query = """
        SELECT
            tb_config_base_url,
            tb_config_id_cliente,
            tb_config_segredo_cliente,
            tb_config_tempo_limite
        FROM tb_config_api_sinistronet
        WHERE tb_config_ativo = true
        LIMIT 1
    """
    df_config = pd.read_sql(query, engine)

    if not df_config.empty:
        return df_config.iloc[0].to_dict()
    return {}

def carregar_config_banco_sinistronet():
    """Busca as credenciais de acesso SQL direto ao banco do Sinistro.net (separado da API REST)."""
    engine = obter_engine()
    query = """
        SELECT
            tb_config_servidor,
            tb_config_banco,
            tb_config_usuario,
            tb_config_senha
        FROM tb_config_banco_sinistronet
        WHERE tb_config_ativo = true
        LIMIT 1
    """
    df_config = pd.read_sql(query, engine)

    if not df_config.empty:
        return df_config.iloc[0].to_dict()
    return {}

def enriquecer_processos_existentes(df_processos, execution_id):
    """
    Faz um 'backfill' (carga histórica) de dados pesados nos processos que já existem.
    Grava o JSON RAW, atualiza Veículo, Status, Fase, Dicionários, SLA, Documentos e Analista Mapfre.
    """
    if df_processos.empty:
        return 0

    engine = obter_engine()

    with engine.begin() as conn:
        for _, row in df_processos.iterrows():
            id_proc = int(row['idProcesso'])
            sinistro = str(row.get('noSinistro', row.get('sinistro', '')))[:50]
            agora = obter_agora_br()

            # ====================================================
            # 0. GRAVAR O JSON CRU (SNAPSHOT + HISTÓRICO)
            # ====================================================
            json_cru = json.dumps(row.to_dict(), ensure_ascii=False)
            hash_json = hashlib.sha256(json_cru.encode("utf-8")).hexdigest()

            existe_bruto = conn.execute(text(
                "SELECT 1 FROM tb_bruto_processos_mapfre WHERE tb_bruto_id_processo_cod = :id_p"
            ), {"id_p": id_proc}).fetchone()
            if existe_bruto:
                conn.execute(text("""
                    UPDATE tb_bruto_processos_mapfre
                    SET tb_bruto_json_completo = :json_cru, tb_bruto_data_captura = :agora
                    WHERE tb_bruto_id_processo_cod = :id_p
                """), {"json_cru": json_cru, "agora": agora, "id_p": id_proc})
            else:
                conn.execute(text("""
                    INSERT INTO tb_bruto_processos_mapfre (tb_bruto_id_processo_cod, tb_bruto_no_sinistro, tb_bruto_json_completo, tb_bruto_data_captura)
                    VALUES (:id_p, :sinistro, :json_cru, :agora)
                """), {"id_p": id_proc, "sinistro": sinistro, "json_cru": json_cru, "agora": agora})

            # Só grava uma nova linha no histórico se o conteúdo mudou desde a
            # última captura (evita empilhar snapshot idêntico a cada execução)
            ultimo_hash = conn.execute(text("""
                SELECT tb_bruto_hash_json FROM tb_bruto_historico_processos_mapfre
                WHERE tb_bruto_id_processo_cod = :id_p
                ORDER BY tb_bruto_data_captura DESC LIMIT 1
            """), {"id_p": id_proc}).fetchone()
            if ultimo_hash is None or ultimo_hash[0] != hash_json:
                conn.execute(text("""
                    INSERT INTO tb_bruto_historico_processos_mapfre (tb_bruto_id_processo_cod, tb_bruto_no_sinistro, tb_bruto_json_completo, tb_bruto_hash_json, tb_bruto_data_captura)
                    VALUES (:id_p, :sinistro, :json_cru, :hash_json, :agora)
                """), {"id_p": id_proc, "sinistro": sinistro, "json_cru": json_cru, "hash_json": hash_json, "agora": agora})

            # ====================================================
            # 1. DIM_PROCESSO (Datas, Fase, Status, Alerta)
            # ====================================================
            dt_bruta = row.get('data_completa_minima')
            dt_abertura = None if pd.isna(dt_bruta) or str(dt_bruta).strip().lower() in ["", "não informada", "nan", "none", "nat"] else dt_bruta

            dt_sinistro_bruta = row.get('data_sinistro')
            dt_sinistro = None if pd.isna(dt_sinistro_bruta) or str(dt_sinistro_bruta).strip().lower() in ["", "nan", "none", "nat"] else dt_sinistro_bruta

            fase_val = row.get('status_processo')
            # 19/03/2026 - Melhoria na captura da Fase/Status
            if pd.isna(fase_val) or str(fase_val).strip().lower() in ['nan', 'none', '', 'null']:
                # Se estiver nulo, tenta a coluna de status corrente como backup
                fase_val = row.get('dsStatusCorrente')

            fase_site = str(fase_val).strip()[:150] if pd.notna(fase_val) else "PROCESSO RECEPCIONADO"

            id_status = row.get('idStatusCorrente')
            id_status_mapfre = int(id_status) if pd.notna(id_status) and str(id_status).strip().lower() not in ['nan', 'none', ''] else None

            alerta_str = str(row.get('flAlerta', '')).strip().upper()
            fl_alerta = alerta_str in ['TRUE', '1', 'S', 'SIM']

            # IMPORTANTE: garante que o status exista em tb_dom_status_mapfre
            # ANTES do UPDATE de tb_dim_processo (que referencia via FOREIGN
            # KEY) -- mesma razão da correção de ordem em
            # registrar_processos_no_banco, ver comentário lá.
            if id_status_mapfre:
                desc_val = row.get('dsStatusCorrente')
                desc_status = "" if pd.isna(desc_val) or str(desc_val).strip().lower() in ['nan', 'none', ''] else str(desc_val).strip()
                desc_st_final = desc_status[:100] if desc_status else f"Status ID: {id_status_mapfre}"

                existe_status = conn.execute(text(
                    "SELECT tb_dom_desc_status_mapfre FROM tb_dom_status_mapfre WHERE tb_dom_id_status_mapfre_cod = :id_st"
                ), {"id_st": id_status_mapfre}).fetchone()
                if not existe_status:
                    conn.execute(text("""
                        INSERT INTO tb_dom_status_mapfre (tb_dom_id_status_mapfre_cod, tb_dom_desc_status_mapfre, tb_dom_fl_status_final)
                        VALUES (:id_st, :desc, false)
                    """), {"id_st": id_status_mapfre, "desc": desc_st_final})
                elif existe_status[0] and existe_status[0].startswith('Status ID:') and not desc_st_final.startswith('Status ID:'):
                    conn.execute(text("""
                        UPDATE tb_dom_status_mapfre SET tb_dom_desc_status_mapfre = :desc
                        WHERE tb_dom_id_status_mapfre_cod = :id_st
                    """), {"id_st": id_status_mapfre, "desc": desc_st_final})

            conn.execute(text("""
                UPDATE tb_dim_processo
                SET tb_dim_dt_abertura_sinistro = COALESCE(tb_dim_dt_abertura_sinistro, :dt_ab),
                    tb_dim_dt_ocorrencia_sinistro = COALESCE(tb_dim_dt_ocorrencia_sinistro, :dt_sin),
                    tb_dim_fase_processo = COALESCE(:stt_proc, tb_dim_fase_processo),
                    tb_dim_id_status_mapfre_cod = COALESCE(:id_status, tb_dim_id_status_mapfre_cod),
                    tb_dim_fl_alerta = :alerta,
                    tb_dim_data_atualizacao = :agora
                WHERE tb_dim_id_processo_cod = :id
            """), {
                "dt_ab": dt_abertura, "dt_sin": dt_sinistro, "stt_proc": fase_site,
                "id_status": id_status_mapfre, "alerta": fl_alerta, "agora": agora, "id": id_proc
            })

            # ====================================================
            # 2. ATUALIZAR VEÍCULO
            # ====================================================
            chassi_bruto = str(row.get('chassi', '')).strip()
            placa_bruta = str(row.get('placa', '')).strip().upper()
            placa = (placa_bruta if placa_bruta and placa_bruta not in ['NAN', 'NONE'] else gerar_placa_placeholder(chassi_bruto))[:10]
            marca = str(row.get('marca', ''))[:50]
            modelo = str(row.get('modelo', ''))[:100]
            valor_fipe = tratar_valor_fipe(row.get('valor_veiculo'))
            sub_modelo = str(row.get('sub_modelo', '')).strip()[:150]
            fl_alienado = bool(int(row.get('flBaixaGravame', 0)))

            ano_val = row.get('ano_fabricacao', row.get('anoVeiculo'))
            try:
                ano_fab = int(float(str(ano_val))) if pd.notna(ano_val) and str(ano_val).lower() not in ['nan', 'none', ''] else None
            except:
                ano_fab = None

            conn.execute(text("""
                UPDATE tb_dim_veiculo
                SET tb_dim_placa = :placa, tb_dim_marca = :marca, tb_dim_modelo = :modelo,
                    tb_dim_ano_fabricacao = :ano_fab, tb_dim_valor_fipe = :vlr,
                    tb_dim_sub_modelo = :sub_modelo, tb_dim_fl_alienado = :fl_alienado,
                    tb_dim_data_atualizacao = :agora
                WHERE tb_dim_id_processo_cod = :id
            """), {
                "placa": placa, "marca": marca, "modelo": modelo, "ano_fab": ano_fab,
                "vlr": valor_fipe, "sub_modelo": sub_modelo if sub_modelo else None,
                "fl_alienado": fl_alienado, "agora": agora, "id": id_proc
            })

            # ====================================================
            # 3. GARANTIR O SLA
            # ====================================================
            existe_sla = conn.execute(text(
                "SELECT 1 FROM tb_fato_sla_processo WHERE tb_fato_id_processo_cod = :id_p"
            ), {"id_p": id_proc}).fetchone()
            if not existe_sla:
                conn.execute(text("""
                    INSERT INTO tb_fato_sla_processo (tb_fato_id_processo_cod, tb_fato_data_recepcao_mapfre, tb_fato_data_captura_robo, tb_fato_status_sla)
                    VALUES (:id_p, :dt, :agora, 'PENDENTE_ENVIO')
                """), {"id_p": id_proc, "dt": dt_abertura, "agora": agora})

            # ====================================================
            # 4. WORKFLOW (tb_dom_status_mapfre já foi resolvido antes do
            #    UPDATE de tb_dim_processo, ver seção 1 acima)
            # ====================================================
            for evento in row.get('workflow', []):
                id_evento = evento.get('idEvento', 0)
                desc_ev_val = str(evento.get('descricao', '')).strip()
                desc_evento = "" if str(desc_ev_val).lower() in ['nan', 'none', ''] else desc_ev_val[:200]
                dt_evento = evento.get('data')

                if id_evento > 0:
                    desc_ev_final = desc_evento[:100] if desc_evento else f"Evento ID: {id_evento}"

                    existe_evento = conn.execute(text(
                        "SELECT tb_dom_desc_evento FROM tb_dom_evento_fluxo WHERE tb_dom_id_evento_mapfre_cod = :id_ev"
                    ), {"id_ev": id_evento}).fetchone()
                    if not existe_evento:
                        conn.execute(text("""
                            INSERT INTO tb_dom_evento_fluxo (tb_dom_id_evento_mapfre_cod, tb_dom_desc_evento, tb_dom_fase_processo)
                            VALUES (:id_ev, :desc, 'Fase a Mapear')
                        """), {"id_ev": id_evento, "desc": desc_ev_final})
                    elif existe_evento[0] and existe_evento[0].startswith('Evento ID:') and not desc_ev_final.startswith('Evento ID:'):
                        conn.execute(text("""
                            UPDATE tb_dom_evento_fluxo SET tb_dom_desc_evento = :desc
                            WHERE tb_dom_id_evento_mapfre_cod = :id_ev
                        """), {"id_ev": id_evento, "desc": desc_ev_final})

                    if dt_evento:
                        existe_fluxo = conn.execute(text(
                            "SELECT tb_fato_descricao_complementar FROM tb_fato_fluxo_mapfre WHERE tb_fato_id_processo_cod = :id_p AND tb_fato_id_evento_mapfre_cod = :id_e"
                        ), {"id_p": id_proc, "id_e": id_evento}).fetchone()
                        if not existe_fluxo:
                            conn.execute(text("""
                                INSERT INTO tb_fato_fluxo_mapfre (tb_fato_id_processo_cod, tb_fato_id_evento_mapfre_cod, tb_fato_descricao_complementar, tb_fato_data_hora_evento, tb_fato_data_cadastro)
                                VALUES (:id_p, :id_e, :desc, :dt, :agora)
                            """), {"id_p": id_proc, "id_e": id_evento, "desc": desc_evento, "dt": dt_evento, "agora": agora})
                        elif desc_evento != '' and not existe_fluxo[0]:
                            conn.execute(text("""
                                UPDATE tb_fato_fluxo_mapfre SET tb_fato_descricao_complementar = :desc
                                WHERE tb_fato_id_processo_cod = :id_p AND tb_fato_id_evento_mapfre_cod = :id_e
                            """), {"desc": desc_evento, "id_p": id_proc, "id_e": id_evento})

            # ====================================================
            # 5. ANALISTA MAPFRE (ENVOLVIDO TIPO 4)
            # ====================================================
            nm_analista = str(row.get('analista_nome', '')).strip()
            email_analista = str(row.get('analista_email', '')).strip()

            if nm_analista and nm_analista.lower() not in ['nan', 'none', '']:
                res_ana = conn.execute(text("SELECT tb_dim_id_envolvido_cod FROM tb_dim_envolvido WHERE tb_dim_id_processo_cod = :id AND tb_dim_id_tipo_envolvido_cod = 4"), {"id": id_proc}).fetchone()

                if not res_ana:
                    conn.execute(text("""
                        INSERT INTO tb_dim_envolvido (tb_dim_id_processo_cod, tb_dim_id_tipo_envolvido_cod, tb_dim_nome, tb_dim_data_cadastro, tb_dim_ativo)
                        VALUES (:id, 4, :nome, :agora, true)
                    """), {"id": id_proc, "nome": nm_analista[:150], "agora": agora})
                    res_ana = conn.execute(text("SELECT tb_dim_id_envolvido_cod FROM tb_dim_envolvido WHERE tb_dim_id_processo_cod = :id AND tb_dim_id_tipo_envolvido_cod = 4"), {"id": id_proc}).fetchone()

                if email_analista and '@' in email_analista:
                    id_env = res_ana[0]
                    existe_contato = conn.execute(text(
                        "SELECT 1 FROM tb_dim_contato WHERE tb_dim_id_envolvido_cod = :id_env AND tb_dim_id_tipo_contato_cod = 3"
                    ), {"id_env": id_env}).fetchone()
                    if not existe_contato:
                        conn.execute(text("""
                            INSERT INTO tb_dim_contato (tb_dim_id_envolvido_cod, tb_dim_id_tipo_contato_cod, tb_dim_valor_contato, tb_dim_fl_principal, tb_dim_data_cadastro, tb_dim_ativo)
                            VALUES (:id_env, 3, :email, true, :agora, true)
                        """), {"id_env": id_env, "email": email_analista[:150], "agora": agora})
                    else:
                        conn.execute(text("""
                            UPDATE tb_dim_contato SET tb_dim_valor_contato = :email
                            WHERE tb_dim_id_envolvido_cod = :id_env AND tb_dim_id_tipo_contato_cod = 3
                        """), {"id_env": id_env, "email": email_analista[:150]})

            # ====================================================
            # 6. EXTRAÇÃO DE DOCUMENTOS
            # ====================================================
            lista_docs = row.get('documentos', row.get('listaDocumentos', row.get('documentosProcesso', [])))
            if isinstance(lista_docs, list) and len(lista_docs) > 0:
                for doc in lista_docs:
                    nome_doc_val = doc.get('dsDocumento', doc.get('nomeDocumento', doc.get('descricao', '')))
                    st_doc_val = doc.get('dsStatus', doc.get('statusDocumento', doc.get('status', '')))

                    nome_doc = "" if pd.isna(nome_doc_val) or str(nome_doc_val).strip().lower() in ['nan', 'none', ''] else str(nome_doc_val).strip()[:200]
                    status_doc = "" if pd.isna(st_doc_val) or str(st_doc_val).strip().lower() in ['nan', 'none', ''] else str(st_doc_val).strip()[:50]

                    if nome_doc and nome_doc.lower() not in ['nan', 'none', '']:
                        existe_doc = conn.execute(text(
                            "SELECT 1 FROM tb_fato_documento WHERE tb_fato_id_processo_cod = :id_p AND tb_fato_nome_documento = :nome"
                        ), {"id_p": id_proc, "nome": nome_doc}).fetchone()
                        if not existe_doc:
                            conn.execute(text("""
                                INSERT INTO tb_fato_documento (tb_fato_id_processo_cod, tb_fato_nome_documento, tb_fato_status_documento, tb_fato_data_cadastro)
                                VALUES (:id_p, :nome, :st, :agora)
                            """), {"id_p": id_proc, "nome": nome_doc, "st": status_doc, "agora": agora})
                        else:
                            conn.execute(text("""
                                UPDATE tb_fato_documento SET tb_fato_status_documento = :st, tb_fato_data_atualizacao = :agora
                                WHERE tb_fato_id_processo_cod = :id_p AND tb_fato_nome_documento = :nome
                            """), {"id_p": id_proc, "nome": nome_doc, "st": status_doc, "agora": agora})

            # ====================================================
            # 7. HISTÓRICO DE USUÁRIO E SLA
            # ====================================================
            id_usuario = int(row.get('idUsuario', 0))
            nm_usuario_origem = str(row.get('usuario_origem', 'SISTEMA'))

            if id_usuario > 0:
                existe_usuario = conn.execute(text(
                    "SELECT 1 FROM tb_dim_usuario_robo WHERE tb_dim_id_usuario_cod = :id_usu OR tb_dim_login_mapfre = :login"
                ), {"id_usu": id_usuario, "login": nm_usuario_origem}).fetchone()
                if not existe_usuario:
                    conn.execute(text("""
                        INSERT INTO tb_dim_usuario_robo (tb_dim_id_usuario_cod, tb_dim_nome_usuario, tb_dim_login_mapfre)
                        VALUES (:id_usu, :login, :login)
                    """), {"id_usu": id_usuario, "login": nm_usuario_origem})

                existe_hist = conn.execute(text(
                    "SELECT 1 FROM tb_fato_historico_usuario_processo WHERE tb_fato_id_processo_cod = :id_p AND tb_fato_id_usuario_cod = :id_usu"
                ), {"id_p": id_proc, "id_usu": id_usuario}).fetchone()
                if not existe_hist:
                    conn.execute(text("""
                        INSERT INTO tb_fato_historico_usuario_processo (tb_fato_id_processo_cod, tb_fato_id_usuario_cod, tb_fato_data_entrada, tb_fato_fl_responsavel_atual)
                        VALUES (:id_p, :id_usu, :agora, true)
                    """), {"id_p": id_proc, "id_usu": id_usuario, "agora": agora})

            existe_sla2 = conn.execute(text(
                "SELECT 1 FROM tb_fato_sla_processo WHERE tb_fato_id_processo_cod = :id_p"
            ), {"id_p": id_proc}).fetchone()
            if not existe_sla2:
                conn.execute(text("""
                    INSERT INTO tb_fato_sla_processo (tb_fato_id_processo_cod, tb_fato_data_recepcao_mapfre, tb_fato_data_captura_robo, tb_fato_status_sla)
                    VALUES (:id_p, :dt_abertura, :agora, 'PENDENTE_ENVIO')
                """), {"id_p": id_proc, "dt_abertura": dt_abertura, "agora": agora})

    return len(df_processos)

# =========================================================================
# FUNÇÕES DE LOG E AUDITORIA
# =========================================================================

def limpar_execucoes_travadas(horas_limite=2):
    """
    Marca como ERRO qualquer execução que ficou presa em 'RODANDO' há mais
    de `horas_limite` horas -- sinal de que o processo morreu sem passar
    pelo finally do main.py (kill externo, crash da máquina, etc; já visto
    em 2026-07-15/16 por motivos diferentes: ExecutionTimeLimit estourado,
    teste interrompido de propósito, e um caso sem causa raiz identificada).
    2h de folga sobre o ExecutionTimeLimit (1h) evita marcar como travada
    uma execução genuinamente ainda em andamento.
    """
    engine = obter_engine()
    agora = obter_agora_br()
    with engine.begin() as conn:
        res = conn.execute(text("""
            UPDATE tb_log_execucao_robo
            SET tb_log_status_execucao = 'ERRO',
                tb_log_data_fim = :agora,
                tb_log_mensagem_geral = 'Execução travada em RODANDO por mais de ' || CAST(:horas AS VARCHAR) || 'h -- marcada automaticamente como ERRO no início da execução seguinte (processo morreu sem passar pelo finally).'
            WHERE tb_log_status_execucao = 'RODANDO'
              AND tb_log_data_inicio < :limite
        """), {"agora": agora, "horas": horas_limite, "limite": agora - pd.Timedelta(hours=horas_limite)})
        if res.rowcount and res.rowcount > 0:
            print(f" -> Aviso: {res.rowcount} execução(ões) travada(s) em RODANDO foram marcadas como ERRO.")

def iniciar_log_execucao(execution_id):
    """Registra o início de uma nova rodada do robô."""
    engine = obter_engine()
    query = text("""
        INSERT INTO tb_log_execucao_robo (tb_log_execution_id_cod, tb_log_data_inicio, tb_log_status_execucao)
        VALUES (:exec_id, :agora, 'RODANDO')
    """)
    with engine.begin() as conn:
        conn.execute(query, {"exec_id": execution_id, "agora": obter_agora_br()})

def finalizar_log_execucao(execution_id, status, qtd_lidos, qtd_novos, mensagem):
    """Atualiza o Log da Execução com o resultado e volumetria final."""
    engine = obter_engine()
    query = text("""
        UPDATE tb_log_execucao_robo
        SET tb_log_data_fim = :agora,
            tb_log_status_execucao = :status,
            tb_log_qtd_processos_lidos = :lidos,
            tb_log_qtd_novos_processos = :novos,
            tb_log_mensagem_geral = :msg
        WHERE tb_log_execution_id_cod = :exec_id
    """)
    with engine.begin() as conn:
        conn.execute(query, {
            "agora": obter_agora_br(), "status": status, "lidos": qtd_lidos, "novos": qtd_novos,
            "msg": str(mensagem)[:4000], "exec_id": execution_id
        })

# =========================================================================
# MOTOR PRINCIPAL DE INGESTÃO (GRAVAÇÃO DE PROCESSOS)
# =========================================================================

def registrar_processos_no_banco(df_processos, execution_id):
    """
    Insere processos novos e distribui os dados nas tabelas satélites.
    Alimentando Dicionários, Documentos e protegendo contra nulos do Pandas.
    """
    if df_processos.empty:
        return 0

    engine = obter_engine()
    mapa_ddd = carregar_mapa_ddd()

    df_existentes = pd.read_sql("SELECT tb_dim_id_processo_cod FROM tb_dim_processo", engine)
    ids_existentes = df_existentes['tb_dim_id_processo_cod'].tolist()

    df_novos = df_processos[~df_processos['idProcesso'].isin(ids_existentes)].copy()
    if df_novos.empty:
        return 0

    with engine.begin() as conn:
        for _, row in df_novos.iterrows():
            id_proc = int(row['idProcesso'])
            sinistro = str(row['noSinistro'])
            agora = obter_agora_br()

            # --- TRATAMENTO DE UF ---
            ddd_bruto = str(row.get('ddd', '')).replace('.0', '').strip()
            ddd_segurado = int(ddd_bruto) if ddd_bruto.isdigit() else None
            uf_processo = mapa_ddd.get(ddd_segurado, str(row.get('dsUF', 'SP')).strip()[:2].upper())

            # ====================================================
            # 0. GRAVAR O JSON CRU (SNAPSHOT + HISTÓRICO)
            # ====================================================
            json_cru = json.dumps(row.to_dict(), ensure_ascii=False)
            hash_json = hashlib.sha256(json_cru.encode("utf-8")).hexdigest()

            existe_bruto = conn.execute(text(
                "SELECT 1 FROM tb_bruto_processos_mapfre WHERE tb_bruto_id_processo_cod = :id_proc"
            ), {"id_proc": id_proc}).fetchone()
            if not existe_bruto:
                conn.execute(text("""
                    INSERT INTO tb_bruto_processos_mapfre (tb_bruto_id_processo_cod, tb_bruto_no_sinistro, tb_bruto_json_completo, tb_bruto_data_captura)
                    VALUES (:id_proc, :sinistro, :json_cru, :agora)
                """), {"id_proc": id_proc, "sinistro": sinistro, "json_cru": json_cru, "agora": agora})

            # Salva a primeira linha no cofre de histórico (já com o hash
            # calculado, pra enriquecer_processos_existentes conseguir comparar
            # a partir da próxima execução)
            conn.execute(text("""
                INSERT INTO tb_bruto_historico_processos_mapfre (tb_bruto_id_processo_cod, tb_bruto_no_sinistro, tb_bruto_json_completo, tb_bruto_hash_json, tb_bruto_data_captura)
                VALUES (:id_proc, :sinistro, :json_cru, :hash_json, :agora)
            """), {"id_proc": id_proc, "sinistro": sinistro, "json_cru": json_cru, "hash_json": hash_json, "agora": agora})

            # ====================================================
            # 1. DIM_PROCESSO (Datas, Fase, Status, Alerta)
            # ====================================================
            dt_bruta = row.get('data_completa_minima')
            dt_abertura = None if pd.isna(dt_bruta) or str(dt_bruta).strip().lower() in ["", "não informada", "nan", "none", "nat"] else dt_bruta

            dt_sinistro_bruta = row.get('data_sinistro')
            dt_sinistro = None if pd.isna(dt_sinistro_bruta) or str(dt_sinistro_bruta).strip().lower() in ["", "nan", "none", "nat"] else dt_sinistro_bruta

            tp_exp = str(row.get('tpExpediente', '')).strip().upper()
            id_expediente = 1 if tp_exp == 'DPA' else (2 if tp_exp == 'TRC' else 0)

            fase_val = row.get('status_processo')
            # 19/03/2026 - Melhoria na captura da Fase/Status
            if pd.isna(fase_val) or str(fase_val).strip().lower() in ['nan', 'none', '', 'null']:
                # Se estiver nulo, tenta a coluna de status corrente como backup
                fase_val = row.get('dsStatusCorrente')

            fase_site = str(fase_val).strip()[:150] if pd.notna(fase_val) else "PROCESSO RECEPCIONADO"

            id_status = row.get('idStatusCorrente')
            id_status_mapfre = int(id_status) if pd.notna(id_status) and str(id_status).strip().lower() not in ['nan', 'none', ''] else None

            alerta_str = str(row.get('flAlerta', '')).strip().upper()
            fl_alerta = alerta_str in ['TRUE', '1', 'S', 'SIM']

            # IMPORTANTE: garante que o status exista em tb_dom_status_mapfre
            # ANTES de inserir tb_dim_processo (que referencia via FOREIGN KEY).
            # No SQL Server antigo isso nunca dava erro porque o banco já tinha
            # meses de status acumulados; num banco novo/vazio, a ordem importa
            # de verdade (achado testando a migração em 2026-07-14).
            if id_status_mapfre:
                desc_val = row.get('dsStatusCorrente')
                desc_status = "" if pd.isna(desc_val) or str(desc_val).strip().lower() in ['nan', 'none', ''] else str(desc_val).strip()
                desc_st_final = desc_status[:100] if desc_status else f"Status ID: {id_status_mapfre}"

                existe_status = conn.execute(text(
                    "SELECT 1 FROM tb_dom_status_mapfre WHERE tb_dom_id_status_mapfre_cod = :id_st"
                ), {"id_st": id_status_mapfre}).fetchone()
                if not existe_status:
                    conn.execute(text("""
                        INSERT INTO tb_dom_status_mapfre (tb_dom_id_status_mapfre_cod, tb_dom_desc_status_mapfre, tb_dom_fl_status_final)
                        VALUES (:id_st, :desc, false)
                    """), {"id_st": id_status_mapfre, "desc": desc_st_final})

            conn.execute(text("""
                INSERT INTO tb_dim_processo (
                    tb_dim_id_processo_cod, tb_dim_no_sinistro, tb_dim_dt_abertura_sinistro,
                    tb_dim_uf_processo, tb_dim_id_tipo_expediente_cod, tb_dim_id_status_mapfre_cod,
                    tb_dim_nm_cia, tb_dim_data_cadastro, tb_dim_ativo, tb_dim_dt_ocorrencia_sinistro,
                    tb_dim_fase_processo, tb_dim_fl_alerta
                ) VALUES (
                    :id_proc, :sinistro, :dt_abertura, :uf, :id_exp, :id_status, 'MAPFRE SEGUROS', :agora, true, :dt_sinistro,
                    :fase_site, :alerta
                )
            """), {
                "id_proc": id_proc, "sinistro": sinistro, "dt_abertura": dt_abertura,
                "uf": uf_processo, "id_exp": id_expediente, "id_status": id_status_mapfre,
                "agora": agora, "dt_sinistro": dt_sinistro, "fase_site": fase_site, "alerta": fl_alerta
            })

            # ====================================================
            # 2. FILA DE TRABALHO
            # ====================================================
            conn.execute(text("""
                INSERT INTO tb_fato_fila_envio (tb_fato_id_processo_cod, tb_fato_id_status_fila_cod, tb_fato_tentativas, tb_fato_data_cadastro, tb_fato_ativo)
                VALUES (:id_proc, 1, 0, :agora, true)
            """), {"id_proc": id_proc, "agora": agora})

            # ====================================================
            # 3. VEÍCULO
            # ====================================================
            chassi = str(row.get('chassi', '')).strip()
            placa = str(row.get('placa', '')).strip().upper()
            if not placa or placa in ['NAN', 'NONE', '']: placa = gerar_placa_placeholder(chassi)

            marca = str(row.get('marca', '')).strip()
            modelo = str(row.get('modelo', '')).strip()
            ano_val = row.get('ano_fabricacao', row.get('anoVeiculo'))
            valor_fipe = tratar_valor_fipe(row.get('valor_veiculo'))
            sub_modelo = str(row.get('sub_modelo', '')).strip()[:150]
            fl_alienado = bool(int(row.get('flBaixaGravame', 0)))

            try:
                ano_fab = int(float(str(ano_val))) if pd.notna(ano_val) and str(ano_val).lower() not in ['nan', 'none', ''] else None
            except:
                ano_fab = None

            conn.execute(text("""
                INSERT INTO tb_dim_veiculo (
                    tb_dim_id_processo_cod, tb_dim_placa, tb_dim_chassi,
                    tb_dim_marca, tb_dim_modelo, tb_dim_ano_fabricacao,
                    tb_dim_valor_fipe, tb_dim_data_cadastro, tb_dim_ativo,
                    tb_dim_sub_modelo, tb_dim_fl_alienado
                ) VALUES (
                    :id_proc, :placa, :chassi, :marca, :modelo, :ano_fab, :vlr_fipe, :agora, true,
                    :sub_modelo, :fl_alienado
                )
            """), {
                "id_proc": id_proc, "placa": placa, "chassi": chassi if chassi else None,
                "marca": marca if marca else None, "modelo": modelo if modelo else None,
                "ano_fab": ano_fab, "vlr_fipe": valor_fipe, "agora": agora,
                "sub_modelo": sub_modelo if sub_modelo else None, "fl_alienado": fl_alienado
            })

            # ====================================================
            # 4. ENVOLVIDOS (SEGURADO, CORRETOR E ANALISTA)
            # ====================================================
            # A) SEGURADO
            nome_envolvido = str(row.get('nomeSegurado', '')).strip()
            cpf = str(row.get('cpfSegurado', '')).strip()
            id_tipo_env = 1 if tp_exp == 'DPA' else (2 if tp_exp == 'TRC' else 1)

            conn.execute(text("""
                INSERT INTO tb_dim_envolvido (tb_dim_id_processo_cod, tb_dim_id_tipo_envolvido_cod, tb_dim_nome, tb_dim_cpf_cnpj, tb_dim_data_cadastro, tb_dim_ativo)
                VALUES (:id_proc, :id_tipo, :nome, :cpf, :agora, true)
            """), {"id_proc": id_proc, "id_tipo": id_tipo_env, "nome": nome_envolvido[:150], "cpf": cpf[:20], "agora": agora})

            res_seg = conn.execute(text("SELECT tb_dim_id_envolvido_cod FROM tb_dim_envolvido WHERE tb_dim_id_processo_cod = :id_proc AND tb_dim_id_tipo_envolvido_cod = :id_tipo ORDER BY tb_dim_id_envolvido_cod DESC LIMIT 1"), {"id_proc": id_proc, "id_tipo": id_tipo_env})
            id_env_seg = res_seg.fetchone()[0]

            emails_brutos = str(row.get('emailSegurado', '')).replace(',', ';')
            for email in [e.strip() for e in emails_brutos.split(';') if '@' in e]:
                conn.execute(text("""
                    INSERT INTO tb_dim_contato (tb_dim_id_envolvido_cod, tb_dim_id_tipo_contato_cod, tb_dim_valor_contato, tb_dim_fl_principal, tb_dim_data_cadastro, tb_dim_ativo)
                    VALUES (:id_env, 3, :email, true, :agora, true)
                """), {"id_env": id_env_seg, "email": email[:150], "agora": agora})

            ddd_seg_final, tel_seg_limpo = higienizar_telefone(row.get('telefoneBeneficiario'), row.get('ddd'))
            if tel_seg_limpo:
                conn.execute(text("""
                    INSERT INTO tb_dim_contato (tb_dim_id_envolvido_cod, tb_dim_id_tipo_contato_cod, tb_dim_ddd_cod, tb_dim_valor_contato, tb_dim_fl_principal, tb_dim_data_cadastro, tb_dim_ativo)
                    VALUES (:id_env, 2, :ddd, :tel, true, :agora, true)
                """), {"id_env": id_env_seg, "ddd": ddd_seg_final, "tel": tel_seg_limpo[:150], "agora": agora})

            # B) CORRETOR
            nm_corretor = str(row.get('nmCorretor', '')).strip()
            if nm_corretor and nm_corretor.lower() not in ['nan', 'none', '']:
                conn.execute(text("""
                    INSERT INTO tb_dim_envolvido (tb_dim_id_processo_cod, tb_dim_id_tipo_envolvido_cod, tb_dim_nome, tb_dim_data_cadastro, tb_dim_ativo)
                    VALUES (:id_proc, 3, :nome, :agora, true)
                """), {"id_proc": id_proc, "nome": nm_corretor[:150], "agora": agora})

                res_corr = conn.execute(text("SELECT tb_dim_id_envolvido_cod FROM tb_dim_envolvido WHERE tb_dim_id_processo_cod = :id_proc AND tb_dim_id_tipo_envolvido_cod = 3 ORDER BY tb_dim_id_envolvido_cod DESC LIMIT 1"), {"id_proc": id_proc})
                id_env_corr = res_corr.fetchone()[0]

                email_corr = str(row.get('emailCorretor', '')).strip()
                if email_corr and '@' in email_corr:
                    conn.execute(text("""
                        INSERT INTO tb_dim_contato (tb_dim_id_envolvido_cod, tb_dim_id_tipo_contato_cod, tb_dim_valor_contato, tb_dim_fl_principal, tb_dim_data_cadastro, tb_dim_ativo)
                        VALUES (:id_env, 3, :email, true, :agora, true)
                    """), {"id_env": id_env_corr, "email": email_corr[:150], "agora": agora})

                ddd_corr_final, tel_corr_limpo = higienizar_telefone(row.get('telefoneCorretor'), row.get('dddCorr'))
                if tel_corr_limpo:
                    conn.execute(text("""
                        INSERT INTO tb_dim_contato (tb_dim_id_envolvido_cod, tb_dim_id_tipo_contato_cod, tb_dim_ddd_cod, tb_dim_valor_contato, tb_dim_fl_principal, tb_dim_data_cadastro, tb_dim_ativo)
                        VALUES (:id_env, 2, :ddd, :tel, true, :agora, true)
                    """), {"id_env": id_env_corr, "ddd": ddd_corr_final, "tel": tel_corr_limpo[:150], "agora": agora})

            # C) ANALISTA MAPFRE
            nm_analista = str(row.get('analista_nome', '')).strip()
            email_analista = str(row.get('analista_email', '')).strip()

            if nm_analista and nm_analista.lower() not in ['nan', 'none', '']:
                conn.execute(text("""
                    INSERT INTO tb_dim_envolvido (tb_dim_id_processo_cod, tb_dim_id_tipo_envolvido_cod, tb_dim_nome, tb_dim_data_cadastro, tb_dim_ativo)
                    VALUES (:id_proc, 4, :nome, :agora, true)
                """), {"id_proc": id_proc, "nome": nm_analista[:150], "agora": agora})

                res_ana = conn.execute(text("SELECT tb_dim_id_envolvido_cod FROM tb_dim_envolvido WHERE tb_dim_id_processo_cod = :id_proc AND tb_dim_id_tipo_envolvido_cod = 4 ORDER BY tb_dim_id_envolvido_cod DESC LIMIT 1"), {"id_proc": id_proc})
                id_env_ana = res_ana.fetchone()[0]

                if email_analista and '@' in email_analista:
                    conn.execute(text("""
                        INSERT INTO tb_dim_contato (tb_dim_id_envolvido_cod, tb_dim_id_tipo_contato_cod, tb_dim_valor_contato, tb_dim_fl_principal, tb_dim_data_cadastro, tb_dim_ativo)
                        VALUES (:id_env, 3, :email, true, :agora, true)
                    """), {"id_env": id_env_ana, "email": email_analista[:150], "agora": agora})

            # ====================================================
            # 5. WORKFLOW (tb_dom_status_mapfre já foi resolvido antes do
            #    INSERT de tb_dim_processo, ver seção 1 acima)
            # ====================================================
            for evento in row.get('workflow', []):
                id_evento = evento.get('idEvento', 0)
                desc_ev_val = str(evento.get('descricao', '')).strip()
                desc_evento = "" if str(desc_ev_val).lower() in ['nan', 'none', ''] else desc_ev_val[:200]
                dt_evento = evento.get('data')

                if id_evento > 0:
                    desc_ev_final = desc_evento[:100] if desc_evento else f"Evento ID: {id_evento}"
                    existe_evento = conn.execute(text(
                        "SELECT 1 FROM tb_dom_evento_fluxo WHERE tb_dom_id_evento_mapfre_cod = :id_ev"
                    ), {"id_ev": id_evento}).fetchone()
                    if not existe_evento:
                        conn.execute(text("""
                            INSERT INTO tb_dom_evento_fluxo (tb_dom_id_evento_mapfre_cod, tb_dom_desc_evento, tb_dom_fase_processo)
                            VALUES (:id_ev, :desc, 'Fase a Mapear')
                        """), {"id_ev": id_evento, "desc": desc_ev_final})

                if dt_evento:
                    conn.execute(text("""
                        INSERT INTO tb_fato_fluxo_mapfre (tb_fato_id_processo_cod, tb_fato_id_evento_mapfre_cod, tb_fato_descricao_complementar, tb_fato_data_hora_evento, tb_fato_data_cadastro)
                        VALUES (:id_proc, :id_e, :desc, :dt, :agora)
                    """), {"id_proc": id_proc, "id_e": id_evento, "desc": desc_evento, "dt": dt_evento, "agora": agora})

            id_ciclo = row.get('idCicloCorrente')
            ds_status_proc = str(row.get('dsStatusCorrenteProcesso', '')).strip()[:200]
            ds_status = str(row.get('dsStatus', '')).strip()[:50]

            if pd.notna(id_ciclo) and int(id_ciclo) > 0:
                conn.execute(text("""
                    INSERT INTO tb_fato_fluxo_etapa (tb_fato_id_processo_cod, tb_fato_id_tarefa_cod, tb_fato_nome_tarefa, tb_fato_status_tarefa, tb_fato_data_hora_etapa, tb_fato_data_cadastro)
                    VALUES (:id_p, :id_c, :nome, :status, :agora, :agora)
                """), {"id_p": id_proc, "id_c": int(id_ciclo), "nome": ds_status_proc, "status": ds_status, "agora": agora})

            # ====================================================
            # 6. DOCUMENTOS
            # ====================================================
            lista_docs = row.get('documentos', row.get('listaDocumentos', row.get('documentosProcesso', [])))
            if isinstance(lista_docs, list) and len(lista_docs) > 0:
                for doc in lista_docs:
                    nome_doc_val = doc.get('dsDocumento', doc.get('nomeDocumento', doc.get('descricao', '')))
                    st_doc_val = doc.get('dsStatus', doc.get('statusDocumento', doc.get('status', '')))

                    nome_doc = "" if pd.isna(nome_doc_val) or str(nome_doc_val).strip().lower() in ['nan', 'none', ''] else str(nome_doc_val).strip()[:200]
                    status_doc = "" if pd.isna(st_doc_val) or str(st_doc_val).strip().lower() in ['nan', 'none', ''] else str(st_doc_val).strip()[:50]

                    if nome_doc and nome_doc.lower() not in ['nan', 'none', '']:
                        existe_doc = conn.execute(text(
                            "SELECT 1 FROM tb_fato_documento WHERE tb_fato_id_processo_cod = :id_p AND tb_fato_nome_documento = :nome"
                        ), {"id_p": id_proc, "nome": nome_doc}).fetchone()
                        if not existe_doc:
                            conn.execute(text("""
                                INSERT INTO tb_fato_documento (tb_fato_id_processo_cod, tb_fato_nome_documento, tb_fato_status_documento, tb_fato_data_cadastro)
                                VALUES (:id_p, :nome, :st, :agora)
                            """), {"id_p": id_proc, "nome": nome_doc, "st": status_doc, "agora": agora})
                        else:
                            conn.execute(text("""
                                UPDATE tb_fato_documento SET tb_fato_status_documento = :st, tb_fato_data_atualizacao = :agora
                                WHERE tb_fato_id_processo_cod = :id_p AND tb_fato_nome_documento = :nome
                            """), {"id_p": id_proc, "nome": nome_doc, "st": status_doc, "agora": agora})

            # ====================================================
            # 7. HISTÓRICO DE USUÁRIO E SLA
            # ====================================================
            id_usuario = int(row.get('idUsuario', 0))
            nm_usuario_origem = str(row.get('usuario_origem', 'SISTEMA'))

            if id_usuario > 0:
                existe_usuario = conn.execute(text(
                    "SELECT 1 FROM tb_dim_usuario_robo WHERE tb_dim_id_usuario_cod = :id_usu OR tb_dim_login_mapfre = :login"
                ), {"id_usu": id_usuario, "login": nm_usuario_origem}).fetchone()
                if not existe_usuario:
                    conn.execute(text("""
                        INSERT INTO tb_dim_usuario_robo (tb_dim_id_usuario_cod, tb_dim_nome_usuario, tb_dim_login_mapfre)
                        VALUES (:id_usu, :login, :login)
                    """), {"id_usu": id_usuario, "login": nm_usuario_origem})

                existe_hist = conn.execute(text(
                    "SELECT 1 FROM tb_fato_historico_usuario_processo WHERE tb_fato_id_processo_cod = :id_p AND tb_fato_id_usuario_cod = :id_usu"
                ), {"id_p": id_proc, "id_usu": id_usuario}).fetchone()
                if not existe_hist:
                    conn.execute(text("""
                        INSERT INTO tb_fato_historico_usuario_processo (tb_fato_id_processo_cod, tb_fato_id_usuario_cod, tb_fato_data_entrada, tb_fato_fl_responsavel_atual)
                        VALUES (:id_p, :id_usu, :agora, true)
                    """), {"id_p": id_proc, "id_usu": id_usuario, "agora": agora})

            existe_sla = conn.execute(text(
                "SELECT 1 FROM tb_fato_sla_processo WHERE tb_fato_id_processo_cod = :id_p"
            ), {"id_p": id_proc}).fetchone()
            if not existe_sla:
                conn.execute(text("""
                    INSERT INTO tb_fato_sla_processo (tb_fato_id_processo_cod, tb_fato_data_recepcao_mapfre, tb_fato_data_captura_robo, tb_fato_status_sla)
                    VALUES (:id_p, :dt_abertura, :agora, 'PENDENTE_ENVIO')
                """), {"id_p": id_proc, "dt_abertura": dt_abertura, "agora": agora})

    return len(df_novos)


# =========================================================================
# FUNÇÕES DE GESTÃO DA FILA (API)
# =========================================================================

def obter_fila_pendente():
    """Lê os dados já tratados diretamente da View no banco."""
    engine = obter_engine()
    # A ordenação agora é feita pela data_mapfre (antiga dt_abertura_original)
    query = "SELECT * FROM vw_processos_prontos_envio ORDER BY data_mapfre ASC"
    return pd.read_sql(query, engine)

def atualizar_status_fila(id_fila, id_processo, status_id, acionamento_id, mensagem, dt_agendamento=None):
    """Atualiza a fila após tentativa de envio e registra o ID de acionamento se sucesso."""
    engine = obter_engine()
    agora = obter_agora_br()
    with engine.begin() as conn:
        conn.execute(text("""
            UPDATE tb_fato_fila_envio
            SET tb_fato_id_status_fila_cod = :status_id,
                tb_fato_tentativas = tb_fato_tentativas + 1,
                tb_fato_data_ultima_tentativa = :agora,
                tb_fato_mensagem_erro = :msg,
                tb_fato_data_hora_agendamento = :dt_agendamento
            WHERE tb_fato_id_fila_cod = :id_fila
        """), {"status_id": status_id, "agora": agora, "msg": mensagem, "dt_agendamento": dt_agendamento, "id_fila": id_fila})

        if status_id == 2:
            conn.execute(text("""
                UPDATE tb_fato_sla_processo
                SET tb_fato_data_envio_sinistronet = :agora,
                    tb_fato_tempo_fila_minutos = date_diff('minute', tb_fato_data_captura_robo, :agora)
                WHERE tb_fato_id_processo_cod = :id_proc
                  AND tb_fato_data_envio_sinistronet IS NULL
            """), {"agora": agora, "id_proc": id_processo})

            # Guarda o acionamentoId devolvido pela API do Sinistro.net -- é o
            # identificador pra localizar esse processo lá depois, se precisar
            # (tb_fato_acionamento_sinistronet existia no schema mas nunca era gravada)
            if acionamento_id:
                existe_acionamento = conn.execute(text(
                    "SELECT 1 FROM tb_fato_acionamento_sinistronet WHERE tb_fato_id_processo_cod = :id_proc"
                ), {"id_proc": id_processo}).fetchone()
                if not existe_acionamento:
                    conn.execute(text("""
                        INSERT INTO tb_fato_acionamento_sinistronet (tb_fato_id_processo_cod, tb_fato_acionamento_id_api, tb_fato_status_sinistronet, tb_fato_data_ultima_sincronizacao, tb_fato_data_cadastro)
                        VALUES (:id_proc, :acionamento_id, 'CADASTRADO', :agora, :agora)
                    """), {"id_proc": id_processo, "acionamento_id": str(acionamento_id), "agora": agora})
                else:
                    conn.execute(text("""
                        UPDATE tb_fato_acionamento_sinistronet
                        SET tb_fato_acionamento_id_api = :acionamento_id,
                            tb_fato_status_sinistronet = 'CADASTRADO',
                            tb_fato_data_ultima_sincronizacao = :agora
                        WHERE tb_fato_id_processo_cod = :id_proc
                    """), {"id_proc": id_processo, "acionamento_id": str(acionamento_id), "agora": agora})

def registrar_log_api(execution_id, id_processo, destino, acao, status_code, payload, resposta):
    """Log técnico detalhado das requisições HTTP."""
    engine = obter_engine()
    with engine.begin() as conn:
        conn.execute(text("""
            INSERT INTO tb_log_transacao_api (tb_log_execution_id_cod, tb_log_id_processo_cod, tb_log_sistema_destino, tb_log_tipo_acao, tb_log_status_code, tb_log_payload_enviado, tb_log_resposta_recebida, tb_log_data_hora_transacao)
            VALUES (:exec_id, :id_proc, :dest, :acao, :status, :pay, :resp, :agora)
        """), {"exec_id": execution_id, "id_proc": id_processo, "dest": destino, "acao": acao, "status": status_code, "pay": str(payload)[:4000], "resp": str(resposta)[:4000], "agora": obter_agora_br()})

def tratar_datas_abertura_banco():
    """
    Usa o banco para extrair a data mínima do Workflow (ELT Puro).
    CORREÇÃO: Garante que a data de abertura seja extraída estritamente do
    histórico individual de cada idProcesso, evitando contaminação entre placas.
    """
    engine = obter_engine()
    query = text("""
        UPDATE tb_dim_processo
        SET tb_dim_dt_abertura_sinistro = w.data_minima
        FROM (
            SELECT tb_fato_id_processo_cod, MIN(tb_fato_data_hora_evento) AS data_minima
            FROM tb_fato_fluxo_mapfre
            -- [TRAVA] Ignora qualquer evento de workflow anterior a 2026
            WHERE tb_fato_data_hora_evento >= '2026-01-01'
            GROUP BY tb_fato_id_processo_cod
        ) w
        WHERE tb_dim_processo.tb_dim_id_processo_cod = w.tb_fato_id_processo_cod
          AND (tb_dim_processo.tb_dim_dt_abertura_sinistro IS NULL
               OR tb_dim_processo.tb_dim_dt_abertura_sinistro < '2026-01-01');
    """)
    with engine.begin() as conn:
        conn.execute(query)

def _conectar_banco_sinistronet():
    """Abre conexão pyodbc direta com o banco SQL do Sinistro.net (Tb_VwEstoqueCompleto etc.)."""
    cfg = carregar_config_banco_sinistronet()
    if not cfg:
        return None

    drivers = pyodbc.drivers()
    if "ODBC Driver 18 for SQL Server" in drivers:
        driver = "{ODBC Driver 18 for SQL Server}"
    elif "ODBC Driver 17 for SQL Server" in drivers:
        driver = "{ODBC Driver 17 for SQL Server}"
    elif "SQL Server" in drivers:
        driver = "{SQL Server}"
    else:
        print(" -> Aviso: nenhum driver ODBC SQL Server encontrado.")
        return None

    con_string = (
        f"Driver={driver};Server={cfg['tb_config_servidor']};Database={cfg['tb_config_banco']};"
        f"UID={cfg['tb_config_usuario']};PWD={cfg['tb_config_senha']};"
    )
    if "ODBC Driver 17" in driver or "ODBC Driver 18" in driver:
        con_string += "Encrypt=yes;TrustServerCertificate=no"

    return pyodbc.connect(con_string, timeout=15)

def _atualizar_cache_estoque_sinistronet_se_necessario(engine, hoje):
    """Consulta a Tb_VwEstoqueCompleto e grava o snapshot do dia -- só roda se ainda não existe cache de hoje."""
    with engine.connect() as conn:
        tem_cache_hoje = conn.execute(text(
            "SELECT COUNT(*) FROM tb_cache_estoque_sinistronet WHERE tb_cache_data_snapshot = :hoje"
        ), {"hoje": hoje}).scalar()

    if tem_cache_hoje:
        print(f" -> Usando cache do dia ({hoje}) -- Sinistro.net não é consultado de novo hoje.")
        return True

    print(" -> Sem cache pra hoje ainda. Consultando Tb_VwEstoqueCompleto (1x por dia)...")
    try:
        conn_remoto = _conectar_banco_sinistronet()
        if conn_remoto is None:
            print(" -> Aviso: credenciais do banco Sinistro.net não configuradas. Pulando conciliação.")
            return False
        with conn_remoto:
            # Cia_Cod = 80 -> Mapfre (mesmo código usado em ID_SOLICITANTE ao acionar a API).
            # Sem esse filtro, um número de sinistro de outra seguradora poderia colidir
            # por coincidência e derrubar da fila um processo da Mapfre que nunca foi enviado.
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=UserWarning)
                df_estoque = pd.read_sql(
                    "SELECT DISTINCT Sinistro FROM Tb_VwEstoqueCompleto WHERE Cia_Cod = 80",
                    conn_remoto
                )
    except Exception as e:
        print(f" -> Aviso: falha ao consultar Tb_VwEstoqueCompleto ({e}). Pulando conciliação.")
        return False

    df_estoque = df_estoque.rename(columns={"Sinistro": "tb_cache_sinistro"})
    df_estoque["tb_cache_data_snapshot"] = hoje

    with engine.begin() as conn:
        conn.execute(text("DELETE FROM tb_cache_estoque_sinistronet"))
    df_estoque.to_sql("tb_cache_estoque_sinistronet", engine, if_exists="append", index=False)

    print(f" -> Cache atualizado: {len(df_estoque)} sinistros Mapfre já cadastrados no Sinistro.net (snapshot {hoje}).")
    return True

def conciliar_fila_com_sinistronet():
    """
    Cruza a fila com o cache diário da Tb_VwEstoqueCompleto (Sinistro.net) e
    retira dela os processos cujo número de sinistro já está cadastrado lá --
    evita reenviar (e duplicar) um acionamento que já existe do lado deles.

    A Tb_VwEstoqueCompleto é atualizada D-1 no Sinistro.net, então só faz
    sentido consultar 1x por dia: a primeira execução do dia lê e salva o
    snapshot local (tb_cache_estoque_sinistronet); as execuções seguintes no
    mesmo dia reaproveitam esse cache em vez de bater no banco remoto de novo.
    """
    engine = obter_engine()
    df_fila = pd.read_sql("SELECT id_fila, sinistro_tratado FROM vw_processos_prontos_envio", engine)
    sinistros_pendentes = df_fila['sinistro_tratado'].dropna().unique().tolist()
    if not sinistros_pendentes:
        return 0

    hoje = obter_agora_br().date()
    if not _atualizar_cache_estoque_sinistronet_se_necessario(engine, hoje):
        return 0

    df_cache = pd.read_sql(
        text("SELECT tb_cache_sinistro FROM tb_cache_estoque_sinistronet WHERE tb_cache_data_snapshot = :hoje"),
        engine, params={"hoje": hoje}
    )
    ja_cadastrados = set(df_cache['tb_cache_sinistro'])
    ids_fila_para_baixar = df_fila.loc[df_fila['sinistro_tratado'].isin(ja_cadastrados), 'id_fila'].tolist()
    if not ids_fila_para_baixar:
        return 0

    agora = obter_agora_br()
    with engine.begin() as conn:
        for id_fila in ids_fila_para_baixar:
            conn.execute(text("""
                UPDATE tb_fato_fila_envio
                SET tb_fato_id_status_fila_cod = 2,
                    tb_fato_mensagem_erro = 'Conciliado - já cadastrado no Sinistro.net (Tb_VwEstoqueCompleto)',
                    tb_fato_data_ultima_tentativa = :agora
                WHERE tb_fato_id_fila_cod = :id_fila
                  AND tb_fato_id_status_fila_cod = 1
            """), {"agora": agora, "id_fila": int(id_fila)})

    print(f" -> {len(ids_fila_para_baixar)} duplicidades removidas da fila (já cadastradas no Sinistro.net).")
    return len(ids_fila_para_baixar)

def obter_ids_processos_existentes():
    """Retorna um set com todos os IDs que já estão salvos no banco de dados."""
    engine = obter_engine()
    try:
        with engine.connect() as conn:
            result = conn.execute(text("SELECT tb_dim_id_processo_cod FROM tb_dim_processo"))
            return {row[0] for row in result}
    except Exception:
        return set()

def registrar_log_notificacao(execution_id, id_processo, status_code, mensagem):
    """Registra o log de disparo do webhook do Power Automate."""
    engine = obter_engine()
    with engine.begin() as conn:
        conn.execute(text("""
            INSERT INTO tb_log_notificacao_power_automate
            (tb_log_execution_id_cod, tb_log_id_processo_cod, tb_log_status_code, tb_log_mensagem_retorno, tb_log_data_hora_disparo)
            VALUES (:exec_id, :id_proc, :status, :msg, :agora)
        """), {
            "exec_id": execution_id,
            "id_proc": id_processo,
            "status": status_code,
            "msg": str(mensagem)[:4000],
            "agora": obter_agora_br()
        })

def registrar_saidas_processos(df_processos_capturados, id_usuario_robo):
    """
    Compara a fila atual da Mapfre com o banco de dados.
    Se um processo estava no banco para este usuário e sumiu da tela, registra a Data de Saída.
    """
    if df_processos_capturados.empty:
        return 0

    engine = obter_engine()
    agora = obter_agora_br()

    # 1. Pega os IDs que o robô acabou de ver na tela da Mapfre
    ids_na_tela = df_processos_capturados['idProcesso'].astype(int).tolist()

    with engine.begin() as conn:
        # 2. Pega os IDs que estão "ativos" (sem data de saída) no nosso banco para este usuário
        query = text("""
            SELECT tb_fato_id_processo_cod
            FROM tb_fato_historico_usuario_processo
            WHERE tb_fato_id_usuario_cod = :id_usu
              AND tb_fato_fl_responsavel_atual = true
        """)
        df_banco = pd.read_sql(query, conn, params={"id_usu": id_usuario_robo})

        if df_banco.empty:
            return 0

        ids_no_banco = df_banco['tb_fato_id_processo_cod'].tolist()

        # 3. A Mágica da Conciliação (O que tem no banco mas NÃO tem na tela)
        ids_saida = list(set(ids_no_banco) - set(ids_na_tela))

        if not ids_saida:
            return 0 # Ninguém saiu da fila

        # 4. Processa as baixas em lotes para evitar sobrecarregar o banco
        for i in range(0, len(ids_saida), 100):
            lote_ids = ids_saida[i:i+100]
            placeholders = ', '.join([str(x) for x in lote_ids])

            # A) Registra a saída no Histórico do Usuário
            conn.execute(text(f"""
                UPDATE tb_fato_historico_usuario_processo
                SET tb_fato_data_saida = :agora,
                    tb_fato_fl_responsavel_atual = false
                WHERE tb_fato_id_usuario_cod = {id_usuario_robo}
                  AND tb_fato_id_processo_cod IN ({placeholders})
            """), {"agora": agora})

            # B) Retira do "Estoque" (Fila de Envio) se o processo saiu antes de ser enviado
            conn.execute(text(f"""
                UPDATE tb_fato_fila_envio
                SET tb_fato_id_status_fila_cod = 2,
                    tb_fato_mensagem_erro = 'Processo finalizado/transferido na Mapfre (Baixa Automática)',
                    tb_fato_data_ultima_tentativa = :agora
                WHERE tb_fato_id_status_fila_cod = 1
                  AND tb_fato_id_processo_cod IN ({placeholders})
            """), {"agora": agora})

    return len(ids_saida)

def sincronizar_processos_existentes(df_processos_capturados, execution_id):
    """
    Escuta alterações em processos que já estão no banco e sincroniza os dados dinâmicos:
    dsStatus, idCicloCorrente, idEvento, fase_processo e flAlerta.
    """
    if df_processos_capturados.empty:
        return 0

    engine = obter_engine()

    # 1. Identifica quem já está no banco
    df_banco = pd.read_sql("SELECT tb_dim_id_processo_cod FROM tb_dim_processo", engine)
    ids_existentes = df_banco['tb_dim_id_processo_cod'].tolist()

    # 2. Separa APENAS os processos que já existem para atualizar
    df_existentes = df_processos_capturados[df_processos_capturados['idProcesso'].isin(ids_existentes)].copy()

    if df_existentes.empty:
        return 0

    with engine.begin() as conn:
        for _, row in df_existentes.iterrows():
            id_proc = int(row['idProcesso'])
            agora = obter_agora_br()

            # ====================================================
            # A) ATUALIZA AS COLUNAS DA TABELA MESTRE (DIMENSÃO)
            # ====================================================
            fase_site = str(row.get('fase_processo', '')).strip()[:150]
            status_mapfre = row.get('idStatusCorrente')
            id_status_mapfre = int(status_mapfre) if pd.notna(status_mapfre) else None

            # Tratamento booleano para o flAlerta
            alerta_str = str(row.get('flAlerta', '')).strip().upper()
            fl_alerta = alerta_str in ['TRUE', '1', 'S', 'SIM']

            conn.execute(text("""
                UPDATE tb_dim_processo
                SET tb_dim_fase_processo = COALESCE(:fase, tb_dim_fase_processo),
                    tb_dim_id_status_mapfre_cod = COALESCE(:id_status, tb_dim_id_status_mapfre_cod),
                    tb_dim_fl_alerta = :alerta,
                    tb_dim_data_atualizacao = :agora
                WHERE tb_dim_id_processo_cod = :id
            """), {"fase": fase_site if fase_site else None, "id_status": id_status_mapfre, "alerta": fl_alerta, "agora": agora, "id": id_proc})

            # ====================================================
            # B) EMPILHA NOVOS EVENTOS DE WORKFLOW (FATO)
            # ====================================================
            for evento in row.get('workflow', []):
                id_evento = evento.get('idEvento', 0)
                dt_evento = evento.get('data')

                if dt_evento:
                    # A checagem de existência faz o papel do "só insere se for alteração/novo"
                    existe_fluxo = conn.execute(text(
                        "SELECT 1 FROM tb_fato_fluxo_mapfre WHERE tb_fato_id_processo_cod = :id_p AND tb_fato_id_evento_mapfre_cod = :id_e"
                    ), {"id_p": id_proc, "id_e": id_evento}).fetchone()
                    if not existe_fluxo:
                        conn.execute(text("""
                            INSERT INTO tb_fato_fluxo_mapfre (tb_fato_id_processo_cod, tb_fato_id_evento_mapfre_cod, tb_fato_descricao_complementar, tb_fato_data_hora_evento, tb_fato_data_cadastro)
                            VALUES (:id_p, :id_e, :desc, :dt, :agora)
                        """), {"id_p": id_proc, "id_e": id_evento, "desc": str(evento.get('descricao', ''))[:200], "dt": dt_evento, "agora": agora})

            # ====================================================
            # C) EMPILHA MUDANÇAS DE CICLO E STATUS (STEPS)
            # ====================================================
            id_ciclo = row.get('idCicloCorrente')
            ds_status_proc = str(row.get('dsStatusCorrenteProcesso', '')).strip()[:200]
            ds_status = str(row.get('dsStatus', '')).strip()[:50]

            if pd.notna(id_ciclo) and int(id_ciclo) > 0:
                existe_etapa = conn.execute(text(
                    "SELECT 1 FROM tb_fato_fluxo_etapa WHERE tb_fato_id_processo_cod = :id_p AND tb_fato_id_tarefa_cod = :id_c"
                ), {"id_p": id_proc, "id_c": int(id_ciclo)}).fetchone()
                if not existe_etapa:
                    conn.execute(text("""
                        INSERT INTO tb_fato_fluxo_etapa (tb_fato_id_processo_cod, tb_fato_id_tarefa_cod, tb_fato_nome_tarefa, tb_fato_status_tarefa, tb_fato_data_hora_etapa, tb_fato_data_cadastro)
                        VALUES (:id_p, :id_c, :nome, :status, :agora, :agora)
                    """), {"id_p": id_proc, "id_c": int(id_ciclo), "nome": ds_status_proc, "status": ds_status, "agora": agora})

    return len(df_existentes)
