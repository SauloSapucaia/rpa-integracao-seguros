# Wrapper usado pela Tarefa Agendada "Robo_Acionamento_Mapfre" -- roda o
# main.py e grava toda a saída (print/erros) num log, já que a tarefa
# executa sem console visível e essa saída se perderia.
$logPath = "M:\8_Sinistro\Mapfre\mapfre_api_v3\logs\robo_execucao.log"
$python = "C:\Users\saulo.sapucaia\AppData\Local\Programs\Python\Python311\python.exe"
$script = "M:\8_Sinistro\Mapfre\mapfre_api_v3\main.py"

# Força UTF-8 dos dois lados -- sem isso o PowerShell 5.1 grava em UTF-16
# por padrão e o log sai ilegível (cada caractere separado por um espaço).
$env:PYTHONIOENCODING = "utf-8"
# Desliga o buffer do Python -- sem isso o print() fica acumulado em memória
# e só grava no log em blocos, então checar o log no meio de uma execução
# longa (modo enriquecimento) podia mostrar informação desatualizada.
$env:PYTHONUNBUFFERED = "1"

# Roda com prioridade mais baixa que o normal -- o robô é majoritariamente
# I/O (esperando resposta da Mapfre, respeitando rate limit), não precisa
# de prioridade de CPU igual a um app em uso ativo. Processos filhos
# herdam a prioridade do processo pai por padrão no Windows, então abaixar
# aqui (o próprio PowerShell) já cobre o python.exe que ele lança depois.
(Get-Process -Id $PID).PriorityClass = "BelowNormal"

Add-Content -Path $logPath -Value ("=== INICIO " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + " ===") -Encoding utf8
& $python $script 2>&1 | Out-File -FilePath $logPath -Append -Encoding utf8
# 2026-07-16: até aqui, o código de saída do Python nunca era checado -- se
# o processo travasse/fosse encerrado por qualquer motivo (achado num caso
# real: execução das 8h cortada aos 15min51s sem chegar no finally do
# main.py), o PowerShell seguia normal e o Agendador registrava "sucesso"
# mesmo assim, mascarando o problema. Agora grava o código real no log e
# propaga como erro do próprio wrapper se for diferente de 0.
$codigoSaidaPython = $LASTEXITCODE
Add-Content -Path $logPath -Value ("=== FIM " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + " (codigo de saida do Python: $codigoSaidaPython) ===" + [Environment]::NewLine) -Encoding utf8

# Backup do banco no M:\ (unidade com rotina de backup), feito AQUI (depois
# do Python encerrar e soltar o lock) pra nunca copiar o arquivo no meio de
# uma escrita. O banco vivo continua só no C:\ -- rodar o motor direto no
# M:\ arriscaria corrupção (mesmo problema de lock de arquivo que travou o
# Git sobre SMB).
#
# Só 1x por dia, às 18h (última execução do dia) -- 2026-07-15: o banco já
# passa de 9GB, copiar isso toda hora (6x/dia) é desnecessário e arrisca
# invadir o horário seguinte, ou pior: se o ExecutionTimeLimit matar o
# processo NO MEIO da cópia, o backup fica corrompido sem ninguém notar.
#
# Cópia atômica: grava com nome temporário e só substitui o backup anterior
# via Move-Item (rename, quase instantâneo) depois de copiar 100% -- se
# travar no meio da cópia, o backup anterior (bom) continua intacto em vez
# de virar um arquivo corrompido.
if ((Get-Date).Hour -eq 18) {
    $destinoDb = "M:\8_Sinistro\Mapfre\1_Backups\Backup_DuckDB\robo_acionamento_backup.duckdb"
    $destinoTmp = "$destinoDb.tmp"
    try {
        $origemDb = "C:\Users\saulo.sapucaia\BancoRobo\robo_acionamento.duckdb"
        Copy-Item -Path $origemDb -Destination $destinoTmp -Force
        Move-Item -Path $destinoTmp -Destination $destinoDb -Force
        Add-Content -Path $logPath -Value ("Backup do banco copiado para M:\ em " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss")) -Encoding utf8
    } catch {
        Add-Content -Path $logPath -Value ("AVISO: falha ao copiar backup do banco para M:\ -- " + $_.Exception.Message) -Encoding utf8
        if (Test-Path $destinoTmp) { Remove-Item -Path $destinoTmp -Force -ErrorAction SilentlyContinue }
    }
}

# Propaga o código de saída do Python pro Agendador de Tarefas -- feito por
# ÚLTIMO (depois do backup) pra o backup sempre tentar rodar mesmo se o
# Python tiver falhado.
if ($codigoSaidaPython -ne 0) {
    exit $codigoSaidaPython
}
