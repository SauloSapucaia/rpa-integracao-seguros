# Documentação — RPA Mapfre → Sinistro.net (mapfre_api_v3)

Última atualização: 2026-07-16.

## 1. O que é o projeto

Robô de automação (RPA) que faz a ponte entre o portal **Gestor de Despachantes da Mapfre**
(`api.gestordespachantes.bbmapfre.com.br`) e o **Sinistro.net** (sistema onde a equipe
trabalha os sinistros). Duas contas de analista (Rafael e Angélica) são usadas pra puxar a
fila de processos da Mapfre; o robô extrai, guarda tudo num banco (**DuckDB**, local, desde
2026-07-14 — ver seção 5) e depois alimenta o Sinistro.net via API, com aviso por e-mail
(Power Automate).

Toda orquestração, fila de processos e auditoria são governadas pelo banco de dados — o
código Python é "burro" de propósito: quase nada é hardcoded, os parâmetros e credenciais
vêm de tabelas de configuração.

## 2. Arquitetura (camadas do banco)

Padrão parecido com um mini data warehouse, adaptado pra um sistema operacional (não é só
analítico — o banco também é a fonte de verdade operacional do robô):

| Camada | Prefixo | O que guarda | Exemplo |
|---|---|---|---|
| Bruta | `tb_bruto_` | JSON cru exatamente como a Mapfre devolve, snapshot + histórico | `tb_bruto_processos_mapfre` |
| Dicionário | `tb_dic_` | Listas fixas/pequenas, viram configuração | `tb_dic_status_fila` |
| Domínio | `tb_dom_` | Listas de referência que crescem com o tempo (a Mapfre pode criar status novo) | `tb_dom_status_mapfre` |
| Dimensão | `tb_dim_` | Cadastros "vivos" (processo, veículo, envolvido, contato) | `tb_dim_processo` |
| Fato | `tb_fato_` | Eventos/movimentações (fila de envio, workflow, SLA, documentos) | `tb_fato_fila_envio` |
| Config | `tb_config_` | Parametrização e credenciais — nada de valor hardcoded no `.py` | `tb_config_credenciais` |
| Log | `tb_log_` | Auditoria de execução, chamadas de API, notificações | `tb_log_execucao_robo` |

Views (`vw_*`) juntam tudo isso em formato "achatado" pronto pra virar payload da API do
Sinistro.net (`vw_processos_prontos_envio`) ou pra relatório de acompanhamento
(`vw_historico_geral_processos`).

## 3. Fluxo de execução (`main.py`)

`executar_robo()` decide o modo pelo horário (`obter_agora_br()`):

- **Sexta 18h → MODO AUDITORIA** (`auditoria.py`): varre processos abertos há mais de 15
  dias, confere status real na Mapfre 1 a 1, e dá baixa sozinho nos que já finalizaram/
  cancelaram lá (sem intervenção humana).
- **8h ou 14h → MODO ENRIQUECIMENTO**: reprocessa processos já existentes, atualiza dados
  que podem ter mudado (endereço, telefone, status). Termina antes do envio pro
  Sinistro.net por segurança. **Histórico (2026-07-15)**: era `8h ou 13h`, mas com o
  agendamento da Tarefa Agendada (08/10/12/14/16/18) o 13h nunca era atingido de verdade —
  trocado por 14h (que já é um dos horários do gatilho), pra ter os 2 horários de
  enriquecimento funcionando de fato por dia.
- **Qualquer outro horário → MODO CAPTURA (fluxo normal)**:
  1. Carrega credenciais/parâmetros do banco.
  2. Extrai da Mapfre só os processos que ainda não estão no banco (`extrair_mapfre`).
  3. Grava bruto + dimensões + fatos (`registrar_processos_no_banco`).
  4. Sincroniza quem já existia (`sincronizar_processos_existentes`).
  5. Dá baixa em quem saiu da fila da Mapfre (`registrar_saidas_processos`).
  6. Processa a fila pendente pro Sinistro.net: monta payload pela view, envia (ou simula,
     conforme `.env`), atualiza status, dispara e-mail de notificação.

**Agendamento de horário de envio ("fila indiana")**: `calcular_data_agendamento` em
`funcoes_auxiliares.py` espaça os envios em incrementos de 5 min, só em horário comercial
(08:15–18:00) e dias úteis, nunca antes da data real de recepção — evita que o Sinistro.net
receba uma rajada de processos ao mesmo tempo.

## 4. Estrutura de arquivos

```
mapfre_api_v3/
  .env                    # DUCKDB_PATH, AMBIENTE, SIMULAR_ENVIO_API
  config.py                # carrega o .env
  database.py              # TODA a lógica de banco (conexão DuckDB, CRUD, dedup por hash)
  mapfre_api.py             # cliente REST do Gestor de Despachantes (login, paginação, detalhe)
  sinistro_api.py           # cliente REST do Sinistro.net + webhook Power Automate
  funcoes_auxiliares.py     # fuso horário, limpeza de valores, regra de agendamento
  auditoria.py              # modo sexta 18h (baixa automática de processos finalizados)
  main.py                   # orquestrador (executar_robo)
  migrar_parquet_para_duckdb.py  # script de uso único que populou o banco DuckDB a partir
                                   # do backup em parquet (já rodado, fica só de referência)
  backfill_analista_mapfre.py    # script de uso único (2026-07-15) que preencheu o Analista
                                   # Mapfre dos processos existentes -- ver seção 9
  executar_robo.ps1              # wrapper chamado pela Tarefa Agendada do Windows -- roda o
                                   # main.py e grava a saída em logs/robo_execucao.log
  logs/
    robo_execucao.log              # saída de cada execução (a tarefa não tem console visível)
  power automate/
    http_request.json              # schema do gatilho HTTP do fluxo de e-mail por processo
    estrutura_e-mail.html          # corpo HTML do fluxo de e-mail por processo
    http_request_erro.json         # schema do gatilho HTTP do fluxo de alerta de falha crítica
    estrutura_e-mail_erro.html     # corpo HTML do fluxo de alerta de falha crítica
  requirements.txt
  sql/
    01_create_tables.sql            # schema T-SQL/SQL Server (histórico, nunca rodou no
                                      # DuckDB — fica pronto caso a TI libere SQL Server um dia)
    02_insert_initial_data.sql      # idem, versão SQL Server
    01_create_tables_duckdb.sql     # OFICIAL hoje — schema DuckDB (rodar 1º)
    02_insert_initial_data_duckdb.sql  # OFICIAL hoje — seed DuckDB (rodar 2º)
    _backup_schema_antigo/          # versões ainda mais antigas (schema em inglês do Fabric)
  _backup_versao_sqlserver/    # database.py/config.py de ANTES da migração DuckDB — ver
                                 # LEIA-ME.md lá dentro pra saber como reverter se precisar
  docs/
    DOCUMENTACAO_PROJETO.md            # este arquivo
    GUIA_NOVO_ROBO_PRESTADOR.md         # como replicar pra outro prestador
```

## 5. Banco de dados — histórico e estado atual

- **Até 2026-07-10**: banco `BD_API_Mapfre` no Microsoft Fabric (SQL Database), autenticação
  via Entra ID (`InteractiveBrowserCredential`).
- **2026-07-10**: decidido encerrar a licença do Fabric. Exportadas as 31 tabelas pra parquet
  (`M:\8_Sinistro\Mapfre\1_Backups\BD_parquet\`, verificadas linha a linha contra o banco,
  bateu 100% -- pasta reorganizada em 2026-07-15, ver seção 9.11),
  schema revisado (índices, `DATETIME2`, nomenclatura 100% português — ver
  `sql/01_create_tables.sql`), tabelas e workspace do Fabric **apagados**.
- **2026-07-14 — migração pra DuckDB**: a TI confirmou que **não vai disponibilizar banco
  nenhum**, Azure está bloqueado pelo tenant, e o usuário **não tem direitos de administrador**
  nesta máquina (confirmado via `WindowsPrincipal`) — então SQL Server Express/PostgreSQL
  local (que exigem instalar serviço) ficaram inviáveis. Adotado **DuckDB**: biblioteca Python
  pura (`pip install duckdb duckdb-engine`, sem admin), motor embutido no processo (sem
  servidor), arquivo único local. Detalhes:

  - **Onde mora o banco**: `C:\Users\saulo.sapucaia\BancoRobo\robo_acionamento.duckdb`
    (disco local, de propósito — DuckDB usa lock de arquivo do SO pro modelo single-writer, e
    compartilhamento de rede `M:\` já deu problema com lock de arquivo nesta mesma sessão,
    com o Git). `.env` aponta pra lá via `DUCKDB_PATH`.
  - **Schema**: `sql/01_create_tables_duckdb.sql` — tradução de sintaxe do T-SQL (que continua
    intacto em `sql/01_create_tables.sql`, sem uso agora, guardado pra se algum dia a TI
    liberar SQL Server de verdade). Diferenças principais: `IDENTITY` → `SEQUENCE` +
    `DEFAULT nextval()`; `OUTER APPLY` → `LEFT JOIN LATERAL ... ON true`; as duas funções T-SQL
    de normalização de telefone (`fn_somente_digitos`+`fn_normalizar_telefone`, com
    `WHILE`/`PATINDEX`) viraram **1 `CREATE MACRO`** usando `regexp_replace` nativo; índices
    manuais removidos (FK já cria índice ART automático no DuckDB).
  - **Migração dos dados**: `migrar_parquet_para_duckdb.py` (uso único, já rodado) carregou as
    31 tabelas direto do parquet (`read_parquet()` nativo, sem passar por pandas) — **as 31
    tabelas bateram 100% em contagem de linhas** contra o parquet de origem. As sequences dos
    IDs auto-incrementais foram criadas já começando depois do maior ID histórico de cada
    tabela (o DuckDB não tem `ALTER SEQUENCE ... RESTART`, então isso tem que ser calculado
    ANTES de criar a tabela).
  - **`database.py` reescrito**: `obter_engine()` trocou toda a autenticação Azure/pyodbc por
    `create_engine(f"duckdb:///{DUCKDB_PATH}")` (via `duckdb-engine`, mantém o mesmo padrão
    `conn.execute(text(...), {...})` do resto do código). Os blocos T-SQL
    `IF NOT EXISTS(...) BEGIN...END` (upsert) viraram `SELECT` + `if/else` em Python — decisão
    deliberada em vez de `ON CONFLICT`, pra preservar exatamente a lógica condicional original
    sem ter que reconstruir cada caso. Todo `DATEADD(HOUR,-3,GETDATE())` virou parâmetro
    `:agora` computado em Python (`funcoes_auxiliares.obter_agora_br()`).
  - **Backup da versão SQL Server**: `_backup_versao_sqlserver/` guarda o `database.py` e
    `config.py` de antes da migração (extraídos do commit `ac98e25` do repo
    `Robo_Acionamento`), com instruções de como reverter se um SQL Server aparecer no futuro.

  ### Duas descobertas reais testando (não é só tradução de sintaxe)

  1. **Ordem de operações importava, e o SQL Server nunca acusou por sorte.**
     `registrar_processos_no_banco`/`enriquecer_processos_existentes` inseriam/atualizavam
     `tb_dim_processo.tb_dim_id_status_mapfre_cod` **antes** de garantir que esse status
     existia em `tb_dom_status_mapfre` (FK). No SQL Server antigo isso nunca dava erro porque
     o banco já tinha meses de status acumulados — praticamente nunca era a *primeira* vez que
     um status aparecia. Num banco novo/vazio, a primeira linha já falhava. **Corrigido**:
     as duas funções agora garantem `tb_dom_status_mapfre` antes do INSERT/UPDATE de
     `tb_dim_processo`.
  2. **Limitação real do DuckDB**: não dá pra fazer `UPDATE` numa coluna que é `FOREIGN KEY`,
     numa linha que já tem outra tabela referenciando ela (o motor reescreve `UPDATE` como
     `DELETE`+`INSERT` internamente, e o `DELETE` esbarra na FK de fora — é um limite conhecido
     do motor, não um erro de sintaxe). A única coluna do schema que o robô atualiza depois da
     linha já ter filhos é essa mesma `tb_dim_id_status_mapfre_cod` — por isso ela **não tem
     `REFERENCES`** na versão DuckDB (tem na versão SQL Server). Integridade continua garantida
     em Python (sempre insere o status antes de usar o ID).
  3. **Dado sujo pré-existente**: 25 de 5.836 contatos telefônicos históricos tinham
     `tb_dim_ddd_cod` inválido (`6`, `620`, `0`...) — nunca foi DDD de verdade, resquício de
     dado ruim de origem. `migrar_parquet_para_duckdb.py` zera esses valores na carga em vez
     de desabilitar a FK pra todo mundo.

  ### Validação end-to-end (2026-07-14, com dado ao vivo real)

  Rodado um teste isolado (extração real da Mapfre + gravação no DuckDB, parando **antes** da
  seção de envio/e-mail pra não arriscar notificação indevida): login das duas contas OK, 789
  processos lidos, **87 processos genuinamente novos gravados de ponta a ponta** (bruto → dim
  → fato → fila), `sincronizar_processos_existentes` e `registrar_saidas_processos` rodaram sem
  erro sobre dado real, e o histórico bruto cresceu exatamente 87 linhas (não 789) — confirma
  que a dedup por hash funciona com dado de produção, não só no teste sintético.

  ### Restrição do DuckDB a ter em mente
  Modelo **single-writer**: só 1 processo escreve no arquivo por vez (lock de SO). Não é
  problema pro uso atual (robô roda agendado, execução única por vez), mas se um dia outro
  processo/pessoa precisar escrever ao mesmo tempo, vai bloquear ou falhar — pensar nisso antes
  de, por exemplo, abrir um segundo robô ou dashboard com escrita simultânea.

- **Pra colocar em produção**: já está — `robo_acionamento.duckdb` já tem o schema e todo o
  histórico migrado. Só falta popular `tb_config_credenciais`/`tb_config_api_sinistronet` com
  os segredos reais se algum dia forem trocados (hoje já tem os que vieram do backup).

## 6. Auditoria contra a documentação oficial da API Sinistro.net (2026-07-13)

Comparado `sinistro_api.py` (`montar_payload`) contra `docs/documentação_api_sinistro.docx`
(documentação oficial da API de abertura de acionamento). Estrutura bate — obrigatórios,
tipos, `document.type` (1=CPF/2=CNPJ), `typeId` de envolvido/corretor/analista (1/3/4, igual
ao exemplo oficial). Achados:

- **Campo `"detalhes"` é enviado mas não existe na documentação oficial** (nem em
  obrigatórios, nem em opcionais). Nunca quebrou nada (API provavelmente ignora campo
  desconhecido), decisão do usuário foi **deixar como está** — só documentando aqui pra não
  precisar re-auditar do zero se um dia for mexer nisso.
- **Campo opcional `ficha` da documentação nunca é enviado** — não tem essa informação vinda
  da Mapfre. **A API também não devolve `ficha` na resposta** (conferido nos 4 exemplos de
  retorno da documentação: 201, 400, 409, 500 — nenhum tem esse campo), então não tem como
  capturar isso de volta.
- **`acionamentoId` (esse sim a API devolve) estava sendo descartado.** Corrigido em
  `database.atualizar_status_fila`: agora grava em `tb_fato_acionamento_sinistronet`
  (tabela que já existia no schema mas nunca era populada) — é o identificador pra localizar
  o processo no Sinistro.net depois, se precisar.
- **Telefone sem padronização de formatação** (não de estrutura — ver nota abaixo): o site
  da Mapfre não limpa espaço/traço no telefone, e o robô só higienizava no primeiro cadastro
  do processo (`registrar_processos_no_banco`), não em atualizações
  (`enriquecer_processos_existentes` nunca mexe em contato de telefone). Corrigido criando
  2 funções SQL — `fn_somente_digitos` e `fn_normalizar_telefone` — aplicadas na leitura de
  `vw_processos_prontos_envio` e `vw_historico_geral_processos` (ver
  `sql/01_create_tables.sql`, seção 4.1). Assim a limpeza acontece sempre, na saída, não
  importa como o dado foi gravado.

  **IMPORTANTE — estrutura real do telefone (confirmado em 2026-07-13 analisando o JSON cru
  de 3.087 processos, `tb_bruto_json_completo`)**: a Mapfre **sempre** manda DDD como campo
  separado (`ddd`/`dddCorr`) — nunca embutido no telefone. Distribuição real de dígitos do
  telefone (só o número, sem DDD): 8-9 dígitos = 5.531 casos válidos; 10-11 dígitos = só 60
  casos, e são lixo (ex: `"0000000000"`), não DDD+número disfarçado. A primeira versão de
  `fn_normalizar_telefone` cortava os 2 primeiros dígitos de qualquer telefone com 10-11
  dígitos assumindo DDD embutido por engano — **suposição errada**, corrigida: agora só
  aceita 8-9 dígitos, sem tentar recortar/recuperar DDD do telefone (nunca é necessário). O
  DDD (usado pela regra de descoberta de UF do processo, `consertar_uf_linha` +
  `tb_dic_ddd_uf`) é uma coluna própria (`tb_dim_ddd_cod`) e nunca é tocado por essa função —
  não corre risco de ser perdido.

## 7. Oportunidades de melhoria (levantadas nesta revisão, não aplicadas)

### Segurança
- `tb_config_credenciais.tb_config_senha_usuario` e
  `tb_config_api_sinistronet.tb_config_segredo_cliente` guardam segredo **em texto plano**.
  Ideal: Azure Key Vault (ou Always Encrypted nessas colunas) antes de popular o banco novo.

### Volume/custo
- `tb_bruto_json_completo` guarda o payload cru inteiro dentro do banco operacional — é o
  que mais pesa no backup/IO. Alternativa: Blob Storage (1 arquivo por captura), só o
  path/hash no banco.

### Qualidade de dado
- CPF/CNPJ chega sujo do pipeline (`.0` de conversão de float) e é remendado toda vez que a
  view é lida (`REPLACE(...,'.0','')`). Melhor normalizar uma vez, no `INSERT`.
- `tb_dic_*` vs `tb_dom_*` fazem a mesma coisa (tabela de referência) sem critério claro
  pra separar — mantido como está, mas seria bom unificar num prefixo só se reescrever o
  robô algum dia.

### Campos do payload da Mapfre não aproveitados (descobertos rodando o robô ao vivo em
2026-07-10, ver `_teste_extracao_mapfre.py`)

Hoje só uma parte do JSON da Mapfre vira coluna estruturada; o resto fica só dentro do
`tb_bruto_json_completo`. Campos que valeria a pena capturar:

| Campo no payload | O que é | Onde entraria |
|---|---|---|
| `valorSaldo` | Saldo em aberto do sinistro | `tb_fato_sla_processo` ou nova coluna em `tb_dim_processo` |
| `dtPrevisaoPagamento` | Data prevista de pagamento | idem |
| `numeroLiquidacao` | Número da liquidação (só existe quando pago) | idem |
| `idTpFinanciamento` / `dsTpFinanciamento` | Tipo de financiamento (ex: "ALIENACAO FIDUCIARIA", "CDC") — hoje só existe o flag booleano `tb_dim_fl_alienado` | `tb_dim_veiculo` |
| `dtRecepcao` | Data de recepção na Mapfre | `tb_fato_sla_processo.tb_fato_data_recepcao_mapfre` já existe mas **não está sendo preenchida** a partir desse campo — conferir |
| `dtAvisoSinistro` | Data do aviso do sinistro (distinta da data de ocorrência) | `tb_dim_processo` |
| `dtHrInicioStatusCorrente` | Desde quando está no status atual | `tb_dim_processo` ou `tb_fato_sla_processo` |
| `noDuvidas` | Quantidade de dúvidas/pendências abertas | `tb_dim_processo` |
| `tpRestricao` / `dsRestricao` | Tipo/descrição de restrição no processo | `tb_dim_processo` |
| `nmKit` | Categoria de cobertura (ex: "Sem Financiamento Segurado Colisão...") | `tb_dim_processo` |
| `flVisualizado` | Se o processo já foi visualizado | `tb_dim_processo` |

Campos vistos mas de significado incerto (vieram nulos na amostra testada, não dá pra
confirmar sem um caso real com valor): `dsCts`, `dsMcaLocalizado`, `cdReferenciaSinistro`.

## 8. Como rodar / testar

- **Pré-requisitos**: Python 3.x, `pip install -r requirements.txt` (inclui `duckdb` e
  `duckdb-engine` desde 2026-07-14). Não precisa mais de ODBC Driver nem login Entra ID pro
  banco — só pro login na Mapfre mesmo (isso não mudou).
- **Rodar o robô completo**: `python main.py` (cuidado — com `SIMULAR_ENVIO_API=False` no
  `.env`, isso cria registros REAIS no Sinistro.net e dispara e-mails reais).
- **`SIMULAR_ENVIO_API=True`** no `.env` é a forma segura de testar o fluxo completo (banco
  + envio) sem mexer no Sinistro.net de verdade — a resposta da API é simulada com sucesso.
  ⚠️ **Corrigido em 2026-07-14**: `config.py` tinha essa flag **hardcoded como `False`**,
  ignorando o `.env` por completo — mudar o `.env` não tinha efeito nenhum antes disso. Agora
  lê de verdade (`os.getenv("SIMULAR_ENVIO_API", "True")`).
  ⚠️ **Histórico (bug corrigido em 2026-07-15, ver seção 9)**: até então, mesmo com `True`, o
  processo simulado caía na mesma trilha de "sucesso" que um envio real — tirava da fila e
  disparava e-mail de verdade, sem nunca ter sido cadastrado no Sinistro.net (a "armadilha").
  **Comportamento atual**: com `True`, o Passo 4 do `main.py` pula o processo inteiro
  (`continue`) — nenhuma chamada de API, nenhuma atualização de status, nenhum e-mail. O
  processo **permanece pendente** até rodar de verdade com `False`. É seguro deixar
  `SIMULAR_ENVIO_API=True` rodando na Tarefa Agendada sem risco de disparo indevido.

### Testar só a extração da Mapfre (sem banco, sem Sinistro.net)

Usado em 2026-07-10 pra confirmar que o robô continuava funcionando e pra descobrir os
campos da seção 7, sem precisar de um banco ativo. `extrair_mapfre()` só depende do dict de
credenciais — não precisa necessariamente vir do banco.

**Se o banco estiver ativo** (caminho normal): `credenciais = database.carregar_credenciais_mapfre()`.

**Se o banco não existir/estiver fora do ar** (como em 2026-07-10, banco recém-migrado):
monte o dict manualmente a partir de qualquer backup de `tb_config_credenciais` que você
tiver (parquet, export antigo, etc.) — mesmo formato que o banco devolveria:

```python
import sys
import pandas as pd

sys.path.insert(0, r"CAMINHO\PARA\mapfre_api_v3")
from mapfre_api import extrair_mapfre

# Ajuste a fonte: parquet de backup, CSV, ou direto do banco se estiver ativo
df = pd.read_parquet(r"CAMINHO\PARA\backup_credenciais.parquet")
df = df[(df["tb_config_sistema"] == "Mapfre") & (df["tb_config_ativo"] == True)]

credenciais = {
    row["tb_config_nome_responsavel"]: {
        "login": row["tb_config_login_usuario"],
        "senha": row["tb_config_senha_usuario"],
    }
    for _, row in df.iterrows()
}

df_mapfre = extrair_mapfre(credenciais)  # só GET — não grava banco, não chama Sinistro.net
print(f"Total extraído: {len(df_mapfre)}")
```

Pontos importantes dessa receita:
- **Read-only de verdade**: `extrair_mapfre` só faz `GET` na API da Mapfre. Não precisa se
  preocupar em sobrecarregar o site — o rate limit de 0,6–1,2s entre requisições já vem
  embutido em `GestorDespachanteAPI._request`, é o mesmo comportamento que já roda em
  produção várias vezes ao dia.
- **Tempo esperado**: em regime de produção sai ~1 processo/segundo depois do login+
  paginação inicial (que tem overhead fixo de 1-2 min). Pra fila de ~360-460 processos por
  conta, espere uns 5-10 min por conta.
- **Nunca versionar o resultado**: o `df_mapfre` tem CPF, telefone e e-mail reais de
  segurados/corretores/analistas — se salvar em CSV/parquet pra inspecionar, é dado
  temporário, apague depois de usar (não é pra ir pro Git nem ficar espalhado em pasta
  compartilhada).

## 9. Sessão 2026-07-15 — conciliação, alertas, produção real e ajustes finos

Primeiro dia com o robô rodando de verdade em cima do DuckDB migrado. Resumo do que mudou,
na ordem em que aconteceu.

### 9.1 Conciliação de duplicidade com o Sinistro.net (`Tb_VwEstoqueCompleto`)

O robô ficou 3 dias parado (motivo: migração DuckDB) e represou 87 processos na fila. Pra
não arriscar cadastrar de novo algo que já tinha sido cadastrado por outro meio nesse
período, ganhamos acesso **de leitura direto** (SQL, não a API REST) ao banco do próprio
Sinistro.net, onde existe a view `Tb_VwEstoqueCompleto` com todos os acionamentos já
cadastrados de todas as seguradoras.

- **Credenciais**: nova tabela `tb_config_banco_sinistronet` (mesmo padrão de
  `tb_config_api_sinistronet`) — servidor `asinistro.database.windows.net`, banco
  `asinistro`, usuário de serviço.
- **Filtro obrigatório `Cia_Cod = 80`** (mesmo código usado em `ID_SOLICITANTE` ao abrir
  acionamento) — sem isso, um número de sinistro de outra seguradora poderia colidir por
  coincidência e derrubar da fila um processo da Mapfre que nunca foi enviado.
- **Cache diário** (`tb_cache_estoque_sinistronet`): a `Tb_VwEstoqueCompleto` é atualizada
  **D-1** do lado do Sinistro.net, então só faz sentido consultar 1x por dia — a primeira
  execução do dia lê e salva o snapshot; as seguintes reaproveitam, sem bater no banco
  remoto de novo. `database.conciliar_fila_com_sinistronet()`.
- **Resultado real no dia**: dos 87 processos represados, **62 já estavam cadastrados**
  (conciliados, saíram da fila sem duplicar) — só 25 eram genuinamente novos.

### 9.2 Corrigida a armadilha do `SIMULAR_ENVIO_API`

Ver aviso atualizado na seção 8. Resumo: com a flag `True`, todo processo pendente (novo ou
antigo) caía na trilha de "sucesso simulado", saía da fila e disparava e-mail de verdade —
sem nunca ter sido cadastrado no Sinistro.net. Corrigido pra pular o processo inteiro
(`continue`) em modo simulado, sem tocar em status nem e-mail.

### 9.3 Alerta de falha crítica por e-mail

Antes, uma falha geral do robô (login Mapfre, banco travado, etc.) só ficava registrada em
`tb_log_execucao_robo` — ninguém era avisado. Implementado:

- **Fluxo e webhook próprios no Power Automate** ("Fluxo de envio de e-mail API Erro -
  Mapfre", cópia do fluxo original pra não misturar payload/schema). URL salva em
  `tb_config_parametros_robo` chave `WEBHOOK_POWER_AUTOMATE_ERRO` (distinta da
  `WEBHOOK_POWER_AUTOMATE` usada pelo e-mail por processo).
- **Destinatários fixos no próprio fluxo** (não dependem do payload): Saulo + Marcus.
- **Método dedicado** `SinistroAPI.notificar_falha_critica()` — payload mais simples que o
  de processo (`execution_id`, `data`, `hora`, `ambiente`, `status_execucao`,
  `mensagem_erro`, `lidos`, `novos`). Chamado pelo `except Exception` do orquestrador em
  `main.py`, **só quando dá erro de verdade** (nunca em sucesso).
- **Limitação conhecida**: só cobre exceção Python. Se o processo for morto pelo Sistema
  Operacional (ex: `ExecutionTimeLimit` da Tarefa Agendada estourando), o `finally` nunca
  roda e nem o log final nem esse alerta disparam — foi exatamente o que aconteceu no
  achado da seção 9.5.

### 9.4 Tarefa Agendada do Windows

O robô agora roda sozinho, sem servidor separado — o banco DuckDB é um arquivo local, então
só pode rodar **nesta máquina** (rodar de um servidor à parte exigiria acessar o arquivo por
rede, que é exatamente o tipo de acesso que o DuckDB não suporta com segurança — mesma
classe de problema do lock do Git sobre SMB).

- **Nome**: `Robo_Acionamento_Mapfre`. Gatilho **semanal, Segunda a Sexta**, das 08h às 18h,
  repetindo a cada 2h (08/10/12/14/16/18). MODO ENRIQUECIMENTO roda às **8h e 14h** (seção 3
  — trocado de 13h pra 14h em 2026-07-15, já que 13h nunca era um horário real do gatilho;
  agora os 2 horários de enriquecimento acontecem de verdade).
- **Ação**: `powershell.exe -WindowStyle Hidden -File executar_robo.ps1` (não chama
  `python.exe` direto — o wrapper existe só pra capturar a saída, ver 9.5).
  **`-WindowStyle Hidden`** adicionado em 2026-07-15: sem isso, o Windows Terminal (definido
  como terminal padrão nesta máquina) abre uma janela visível que não fecha sozinha depois
  que o script termina (o script nunca imprime nada na tela mesmo, tudo vai pro log) —
  ficava uma janela "vazia" que o usuário precisava fechar na mão a cada execução.
- **`MultipleInstances = IgnoreNew`**: se uma execução ainda estiver rodando quando o
  próximo gatilho disparar, o novo disparo é ignorado (não sobe um segundo processo em
  paralelo — importante porque o DuckDB é single-writer).
- **`ExecutionTimeLimit = 1h`**: decisão do usuário, mesmo sabendo que o pior caso
  histórico (ver 9.5) foi 1h02m46s — ligeiramente acima. Risco aceito conscientemente.
- **Detalhe do próprio `main.py`, não mudou hoje**: toda sexta 18h entra em "MODO AUDITORIA
  DE LIMPEZA" em vez do fluxo normal (ver seção 3).

### 9.5 Bug real: timeout matando o modo enriquecimento

A execução das 08h de 2026-07-15 ficou travada em `RODANDO` pra sempre (sem `data_fim`, sem
disparar o alerta da seção 9.3 — exatamente a limitação descrita lá). Causa: `main.py` entra
em MODO ENRIQUECIMENTO às 8h (na época, o único horário real do agendamento -- 13h nunca era
alcançado; ver 9.4 sobre a troca por 14h) -- backfill pesado de processos já existentes -- e isso
estourou o `ExecutionTimeLimit` de 30min que a tarefa tinha no momento (`0x41306` =
SCHED_S_TASK_TERMINATED). Como é morte forçada pelo SO, não é uma exceção Python — o
`finally` nunca roda.

**Como o tempo certo foi decidido**: em vez de chutar um número, puxamos
`dbo.tb_log_execucao_robo.parquet` (891 execuções históricas reais, antes da migração) e
calculamos a duração real de cada uma. Achado: **maior execução de todas: 1h02m46s**; maior
especificamente em execuções que começaram às 8h ou 13h (histórico anterior a esse
agendamento, quando os dois horários existiam): 55min18s; média do enriquecimento: ~38min.
`ExecutionTimeLimit` ajustado com base nesse dado real (ver decisão final em 9.4).

**Correções que vieram junto**:
- Linha travada em `RODANDO` corrigida manualmente pra `ERRO` (mais 2 fantasmas antigos
  achados e corrigidos numa revisão geral depois: um de março/era Fabric, outro de um teste
  interrompido de propósito nesta própria sessão).
- Criado `executar_robo.ps1` — a tarefa não tinha console visível, então toda a saída
  (`print()`) do robô estava se perdendo. Agora grava em `logs\robo_execucao.log`.
  **Detalhe técnico**: precisa forçar UTF-8 dos dois lados
  (`$env:PYTHONIOENCODING="utf-8"` no PowerShell + `-Encoding utf8` no
  `Out-File`/`Add-Content`) — sem isso o PowerShell 5.1 grava em UTF-16 por padrão e o log
  sai ilegível (cada caractere separado por espaço).

### 9.6 Primeiro envio real em produção

`SIMULAR_ENVIO_API` virado pra `False` e rodado manualmente: **22 de 22 processos
cadastrados com sucesso** no Sinistro.net (`AcionamentoId` 311901–311922), 0 erro, 0
conflito, 22 e-mails reais disparados. A partir daqui o robô está em produção de verdade.

### 9.7 Três correções no e-mail de notificação (validadas com dado real)

1. **Data** — `data_mapfre` vinha cru (`2026-07-14 14:10:07`). Criado
   `SinistroAPI._formatar_data_br()` → `dd/mm/aaaa hh:mm`.
2. **Telefone** — DDD+número concatenados sem separador, e com artefato de conversão float
   no DDD (`ddd_segurado='11.0'` fazia o e-mail mostrar `11.0992017762`). Criado
   `SinistroAPI._formatar_telefone_br(ddd, numero)` → `(11) 99201-7762` / `(11) 2954-0538`.
3. **Analista Mapfre nunca chegava** — bug real em `mapfre_api.py:290-291`: o nome/e-mail
   do analista (`nmAnalista`/`emailAnalistaTw`) era lido de `p_basico` (dados básicos da
   listagem, sem esse campo) em vez de `processo_completo` (já mesclado com
   `detalhe_id`/`detalhe_acomp`, onde o dado de fato vem preenchido). Todos os outros campos
   do payload já liam corretamente de `processo_completo`; só esses dois ficaram pra trás.
   Corrigido pra ler de `processo_completo`.

**Critério usado pra decidir o que mexer**: só é seguro alterar/popular um campo do
`montar_payload()` (API real do Sinistro.net) se ele já faz parte da estrutura documentada
no manual da API (mesmo que estivesse sempre vazio por bug) — destravar um campo já
previsto é OK, adicionar campo novo fora da estrutura validada não é. O campo `analista`
(`typeId: 4`) já existia em `montar_payload()` esperando esse dado — corrigir a captura fez
esse campo (que já era enviado à API, só que sempre vazio) começar a ir preenchido de
verdade, sem mudar a estrutura do payload.

**Limitação que ficou aberta**: a correção #3 só vale pra processos **novos** — a busca de
detalhe completo (`detalhe_id`/`detalhe_acomp`, onde o analista vem) só roda em
`mapfre_api.py` pra IDs que ainda não existem no banco (`if id_proc not in ids_existentes`).
Processos já existentes nunca passam por ali, então o modo enriquecimento sozinho nunca
conseguiria preencher o analista deles — daria pra "consertar" isso fazendo o enriquecimento
sempre buscar o detalhe de novo, mas isso pioraria exatamente o problema de tempo de
execução da seção 9.5. Resolvido via backfill pontual em vez de mudar o pipeline (ver 9.8).

### 9.8 Backfill do Analista Mapfre em processos existentes

Levantamento: de 3.335 processos ativos, **2.472 (74%) estavam sem o analista Mapfre**
cadastrado (a extração normal nunca buscava o detalhe completo pra eles — ver limitação da
seção 9.7). Rodado `backfill_analista_mapfre.py` (uso único): autentica numa conta Mapfre,
busca `SELECT` dos processos sem analista, chama `buscar_processo_por_id()` individualmente
pra cada um (mesmo rate limit de produção, ~0,6-1,2s entre chamadas) e grava
nome/e-mail em `tb_dim_envolvido`/`tb_dim_contato` (tipo 4) — sem repetir o enriquecimento
pesado inteiro, só essa peça específica. Depois de rodar 1x, não precisa rodar de novo:
processos novos já vêm certos desde a correção da seção 9.7.

**Resultado (concluído em 2026-07-15)**: 2.472/2.472 processados, **100% preenchidos**, 0
erro, 0 sem dado na API — rodou em ~37,6min (2.259s). Conferido depois: **3.335/3.335
processos ativos com analista Mapfre cadastrado** (100%).

### 9.9 Limpeza: `tb_log_anomalia_negocio` removida

Tabela existia no schema desde a era Fabric (`tb_log_id_anomalia_cod`, `tb_log_tipo_anomalia`,
etc.) mas **nenhum código nunca gravou nela** — só a migração do parquet a carregava (vazia).
Removida de `sql/01_create_tables_duckdb.sql`, `sql/01_create_tables.sql` e do banco DuckDB
ao vivo (mantido só um comentário no lugar, caso surja um uso real no futuro). O parquet
original (`dbo.tb_log_anomalia_negocio.parquet`) não foi apagado — continua como backup
histórico em `1_Backups\BD_parquet\`.

### 9.10 Backup do banco DuckDB pro M:\

O `.duckdb` vivo fica só em `C:\Users\saulo.sapucaia\BancoRobo\` (disco local, sem rotina de
backup) — mas **rodar o banco vivo direto no M:\ não é opção** (mesmo problema de lock de
arquivo sobre SMB que já travou o Git nesta sessão, arriscaria corrupção). Solução: copiar,
não mover. `executar_robo.ps1` copia o arquivo pro M:\
(`1_Backups\Backup_DuckDB\robo_acionamento_backup.duckdb`) **depois** do Python encerrar e
soltar o lock, pra nunca copiar em cima de uma escrita ativa.

**Ajustado em 2026-07-15** (banco já passa de 9GB): copiar isso a cada execução (6x/dia) foi
identificado como arriscado -- podia invadir o horário seguinte, ou pior, se o
`ExecutionTimeLimit` matasse o processo **no meio da cópia**, o backup ficaria corrompido
sem ninguém perceber. Duas correções:
- **Frequência**: só roda **1x por dia, às 18h** (última execução do dia) -- decisão do
  usuário, mesma lógica de horário fixo do modo enriquecimento (seção 3).
- **Cópia atômica**: copia primeiro com sufixo `.tmp`, só substitui o backup anterior via
  `Move-Item` (rename, quase instantâneo) depois de copiar 100%. Se travar no meio da cópia
  do `.tmp`, o backup anterior (bom) continua intacto -- nunca fica um backup pela metade no
  lugar do definitivo.

### 9.14 Checkpoint de progresso pra execuções longas

O modo enriquecimento pode passar de 40min, e a única forma de acompanhar era esperar
terminar ou ler o log parcial "no escuro" (contando linhas `Detalhando ID` manualmente).
Duas melhorias em 2026-07-15:

- **`executar_robo.ps1`**: `$env:PYTHONUNBUFFERED = "1"` -- sem isso, o `print()` do Python
  fica acumulado em buffer de memória e só grava no log em blocos (não em tempo real), então
  ler o log no meio de uma execução longa podia mostrar informação desatualizada.
- **`mapfre_api.py` (`extrair_mapfre`)**: o loop de detalhamento agora imprime uma linha
  `[Progresso] <conta>: X/Y detalhados (Z%)` a cada 50 processos (e sempre no último) --
  em vez de ter que contar linhas `Detalhando ID`, basta procurar a última linha
  `[Progresso]` no log pra saber exatamente onde a execução está, sem esperar terminar.

### 9.15 Prioridade de processo mais baixa

Preocupação do usuário: o robô roda na própria máquina de trabalho dele (Tarefa Agendada
`LogonType=Interactive`, necessário pro mapeamento do M:\ funcionar), e ele não queria que
execuções ficassem competindo por CPU com o trabalho normal do dia. Como o robô é
majoritariamente I/O (esperando resposta HTTP da Mapfre, respeitando rate limit de
~0,6-1,2s entre chamadas) e não CPU-bound, a solução foi baixar a prioridade do processo:
`(Get-Process -Id $PID).PriorityClass = "BelowNormal"` logo no início de `executar_robo.ps1`
-- processos filhos herdam a prioridade do pai por padrão no Windows, então isso já cobre o
`python.exe` lançado depois, sem precisar mexer em mais nada.

### 9.16 Checagem de disponibilidade da Mapfre antes de autenticar

Não existia nenhuma checagem se o site da Mapfre estava no ar antes do robô tentar logar de
verdade -- se estivesse fora do ar, cada conta ia gastar o tempo inteiro de retry (3
tentativas com backoff exponencial) só pra falhar, e o resultado final podia ser só "0
processos lidos" sem nenhum sinal claro do motivo. Criada
`mapfre_api.verificar_disponibilidade_mapfre()`: um `GET` simples e rápido (timeout 10s,
sem login) na URL pública (`FRONT_URL`) antes de entrar no loop de contas -- status < 500
(ou qualquer resposta 2xx-4xx) conta como "disponível"; timeout, falha de conexão ou erro
5xx conta como fora do ar. Se falhar, `main.py` levanta exceção imediatamente (Passo 2,
antes do loop de credenciais) -- isso cai no `except Exception` do orquestrador, marca a
execução como `ERRO` com mensagem clara ("Site da Mapfre não respondeu...") e **dispara o
alerta de falha crítica** (seção 9.3) pra Saulo/Marcus, em vez de falhar silenciosamente.

**Ajuste no mesmo dia (achado pelo usuário)**: a primeira versão fazia 1 tentativa só, sem
retry -- deixando essa checagem *menos* tolerante a um soluço passageiro do que o resto do
robô (cada chamada de login já tem 3 retries com backoff em
`GestorDespachanteAPI._request`). Um blip de 1 request não devia poder abortar a execução
inteira. Corrigido pra **2 tentativas com 2s de espera entre elas** -- ainda bem mais barato
que deixar as 2 contas baterem a cabeça nos 3 retries completos cada uma só pra descobrir
que está tudo fora do ar, mas já não confunde um soluço isolado com "fora do ar" de verdade.
Testado contra o site real: disponível, ~0,3s (retry só entra em ação se a 1ª tentativa
falhar de verdade).

### 9.11 Registro permanente do export Fabric original

Cópia rotulada dos 31 parquets originais em
`1_Backups\Backup_Fabric_Original_2026-07-10\` (com `LEIA-ME.md` explicando o porquê) —
separada da cópia de trabalho em `BD_parquet\`, garantindo um ponto de referência histórico
inequívoco (rotulado com a data exata do export, 2026-07-10) caso `BD_parquet\` seja um dia
reorganizada, limpa ou reutilizada.

### 9.12 Reorganização de pastas em `M:\8_Sinistro\Mapfre\`

Criada `1_Backups\` pra agrupar tudo que é backup/histórico (antes soltas direto na raiz):
`BD_parquet\`, `Backup_Fabric_Original_2026-07-10\` (seção 9.11) e `Backup_DuckDB\` (seção
9.10). `mapfre_api_v3\` (código vivo, tem a Tarefa Agendada com caminho absoluto) e
`0_Outros_materiais\` **não foram movidas** — risco desnecessário. Caminhos atualizados em
`executar_robo.ps1` e nos 3 scripts que referenciam `BD_parquet`
(`migrar_parquet_para_duckdb.py`, `verificar_exportacao.py`, `exportar_tabelas_parquet.py`).

### 9.17 Sincronização automática de senha via planilha

O fluxo antigo (Power Automate, formulário → escrita direta no banco Fabric) ficou
inutilizável com a migração -- o Fabric foi apagado, e o banco novo (DuckDB) é um arquivo
local que o Power Automate não tem como alcançar (sem conector, e as alternativas -- Graph
API/App Registration, Gateway de Dados Local -- esbarram nas mesmas duas restrições que já
definiram a arquitetura toda: TI não libera Azure, usuário sem admin na máquina).

**Solução adotada**: `M:\8_Sinistro\Mapfre\Controle_Senhas_Mapfre.xlsx` -- planilha simples
(colunas `Conta`, `Senha`, `Instrucao`) no mesmo compartilhamento de rede que o robô já lê/
escreve sem nenhuma permissão nova. `database.sincronizar_senhas_planilha()` roda logo no
Passo 1 do `main.py` (antes de carregar as credenciais, pra a própria execução já usar a
senha nova se ela tiver mudado), compara cada linha com `tb_config_credenciais` e aplica
automaticamente se for diferente. Quem precisar trocar a senha de uma conta só abre a
planilha e digita -- a próxima execução (no máximo 2h depois) já aplica sozinha, sem
intervenção manual em lugar nenhum.

**Planilha nasce com a senha em branco** (não com o valor atual) -- gerada só com os nomes
das contas ativas; popular ela com a senha real já em uso seria duplicar segredo vivo num
arquivo novo à toa (achado pelo classificador de segurança do Auto Mode ao tentar isso).
Célula vazia = sem ação (a sincronização ignora linhas sem senha preenchida).

### 9.18 Alerta de falha de login por conta

Antes, se a senha do Rafael (ou Angélica) travasse/expirasse, `extrair_mapfre` só pulava a
conta silenciosamente (`except Exception: print(...); continue`) -- o robô seguia rodando
"com sucesso" só com a conta que funcionou, sem ninguém ser avisado. Se as duas travassem ao
mesmo tempo, virava "SUCESSO, 0 lidos" sem explicação nenhuma.

**Corrigido**: `extrair_mapfre()` agora retorna uma tupla `(df_final, contas_com_falha)` --
`contas_com_falha` é uma lista de `(nome_conta, mensagem_erro)` de quem não conseguiu logar.
`main.py`, logo depois da extração, dispara `SinistroAPI.notificar_falha_critica()`
(reaproveita o mesmo webhook/e-mail do alerta de falha geral, seção 9.3, `status_execucao=
"ALERTA_LOGIN_MAPFRE"`) se essa lista não estiver vazia -- **sem abortar a execução**: o
robô continua processando o que a(s) conta(s) que funcionou(aram) trouxe(ram) normalmente,
só avisa em paralelo sobre a conta com problema. Mensagem já sugere checar a planilha
`Controle_Senhas_Mapfre.xlsx` (seção 9.17) ou o portal diretamente.

Testado com conta falsa (login/senha inválidos de propósito): `extrair_mapfre` retornou
`contas_com_falha = [('ContaFalsaTeste', 'Falha na requisição de login (Sem resposta).')]`
corretamente, sem afetar a captura de outras contas.

### 9.13 Estado ao final do dia

- Robô em produção real, `SIMULAR_ENVIO_API=False`, Tarefa Agendada ativa.
- Git **intocado de propósito** — decisão do usuário: só commitar/empurrar quando a
  estrutura inteira estiver finalizada e validada rodando (não fazer commits incrementais
  nesse meio tempo).
- **Alerta de login por conta** (seção 9.18) e **sincronização de senha via planilha**
  (seção 9.17) implementados e testados no mesmo dia.
- **Fluxo de senha via planilha** (seção 9.17) ativo -- `Controle_Senhas_Mapfre.xlsx` criada,
  sincronização testada (0 atualizações com planilha em branco, como esperado).

## 10. Sessão 2026-07-16 — primeiro dia real sem supervisão direta

### 10.1 Execução das 8h cortada no meio (causa raiz não identificada)

A execução das 8h (modo enriquecimento) rodou de `08:00:02` até `08:15:53` (15min51s) e
**parou no meio do detalhamento da conta do Rafael** (~78%+ concluído, nunca terminou Rafael,
nunca começou Angélica, nunca chegou nas etapas de envio). Não foi o `ExecutionTimeLimit`
(1h) -- parou bem antes disso.

**Investigado e descartado**: sem evento de suspensão/hibernação da máquina (`powercfg
/lastwake` vazio, sem evento 42/507 no log System), sem erro de aplicação no Event Viewer
nesse intervalo.

**Achado real**: o log do Agendador de Tarefas (`Microsoft-Windows-TaskScheduler/Operational`)
confirma que o `powershell.exe` da tarefa terminou com **código de retorno 0** às 08:15:53 --
ou seja, não foi morto external pelo SO com erro visível, mas também não terminou pelo
caminho normal do `main.py` (não há linha "EXECUÇÃO FINALIZADA" nem "Status: SUCESSO/ERRO" no
log depois do ponto de corte). **Causa raiz do próprio corte não identificada** -- os sintomas
batem com o `python.exe` tendo sido encerrado abruptamente por algo fora do próprio código
(não uma exceção Python normal, que teria sido capturada pelo `try/except` do orquestrador e
passaria pelo `finally`).

**O que ficou claro e foi corrigido**: o `executar_robo.ps1` **nunca checava o código de
saída do Python** -- por isso o Agendador registrava "sucesso" mesmo com o processo morrendo
no meio. Corrigido: `$codigoSaidaPython = $LASTEXITCODE` gravado no log, e o wrapper agora
propaga esse código (`exit $codigoSaidaPython` se != 0) -- a partir de agora, se isso
acontecer de novo, o Agendador vai registrar a falha de verdade em vez de mascarar como
sucesso, o que também ajuda a investigar (e talvez identificar o padrão) numa próxima
ocorrência.

**Limpeza automática de execuções travadas**: já foi a 3ª vez vendo uma linha presa em
`RODANDO` (antes: timeout do `ExecutionTimeLimit` antigo de 30min; teste interrompido de
propósito; agora este caso sem causa identificada). Criada
`database.limpar_execucoes_travadas(horas_limite=2)`, chamada logo no início do
`executar_robo()` (antes até de `iniciar_log_execucao`) -- marca como `ERRO` qualquer linha
travada em `RODANDO` há mais de 2h (folga sobre o `ExecutionTimeLimit` de 1h, pra nunca marcar
uma execução genuinamente em andamento). Não resolve a causa raiz, mas garante que o banco
nunca mais fica com registro fantasma esperando alguém notar e corrigir na mão.

**Linha de hoje corrigida manualmente** (a limpeza automática só entra em vigor pra próxima
vez -- essa em si tinha só ~1h45 quando descoberta, abaixo do limiar de 2h).

### 10.2 Bug real: colisão da placa placeholder "AVI0000" (achado grave)

Investigando por que o processo 213789 (10h) tomou 409 mesmo sem duplicata de sinistro/chassi
(usuário conferiu no próprio site do Sinistro.net por Nº Sinistro e por Chassi, nenhum resultado),
achamos a causa raiz: `registrar_processos_no_banco`/`enriquecer_processos_existentes` usavam o
valor fixo **`"AVI0000"`** pra TODO processo sem placa real vinda da Mapfre. O Sinistro.net só
permite **1 acionamento aberto por placa** -- então o primeiro processo sem placa que é enviado
"tranca" `AVI0000`, e todo processo seguinte sem placa (sinistro/veículo completamente
diferentes) toma 409 achando que é duplicata da mesma placa.

**Tamanho do estrago**: consultamos a `Tb_VwEstoqueCompleto` pra cada um dos 157 processos em
status Conflito -- **36 (23%) tinham a mensagem de erro citando "AVI0000"**. Checando cada um
desses 36 sinistros na `Tb_VwEstoqueCompleto`: **35 já estavam cadastrados de verdade** (com
placa real, corrigida manualmente pela equipe quando trabalha o processo -- **reenviar teria
criado 35 duplicatas reais**, por isso não reenviamos às cegas). Só **2 (processos 213786 e
213789) nunca foram cadastrados** -- esses sim reenfileirados (status 1) depois da correção.

**Correção**: `funcoes_auxiliares.gerar_placa_placeholder(chassi)` -- usa os 4 últimos
caracteres do chassi (VIN, praticamente único por veículo) em vez de um valor fixo, mantendo o
mesmo formato de 7 caracteres (`"AVI" + 4 chars`) que já era aceito pela API. Decisão do
usuário: 4 caracteres reduz drasticamente a colisão mas não zera 100% -- **não foi só
preferência de formato**: a alternativa de usar mais caracteres (6-7 do chassi, ou combinar
com o ID do processo) **não seria aceita pela API do Sinistro.net**, que valida o formato da
placa (7 caracteres, padrão `AAA9999`) -- qualquer coisa fora desse formato seria rejeitada
antes mesmo de chegar na regra de duplicidade. Então 7 caracteres é uma restrição real da API,
não uma escolha estética. Aplicado
nos 3 pontos que geravam a placa: `database.registrar_processos_no_banco`,
`database.enriquecer_processos_existentes`, e o fallback em `sinistro_api.montar_payload`
(defesa em profundidade, só age se a placa gravada estiver genuinamente vazia). Os 2 processos
reenfileirados também tiveram a placa **já gravada** corrigida na mão (`AVI0000` →
`AVI8521`/`AVI9866`) -- só corrigir o código novo não bastaria, porque `montar_payload` usa a
placa já salva no banco quando ela não está vazia (só cai no gerador quando é `None`/branco).

**Verificação de escopo**: só 3 processos no total tinham `AVI0000` gravado em
`tb_dim_veiculo` -- os 2 reenfileirados + 1 que já tinha sucesso (status 2, é o próprio
"dono" do acionamento que estava bloqueando os outros -- não precisa de correção).

### 10.3 Resultado das outras execuções de hoje

10h e execuções seguintes: sem novidade a reportar além do que já estava validado --
seguir monitorando.
