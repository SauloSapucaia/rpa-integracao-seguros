import time
import sys
from sqlalchemy import text
import database
from database import obter_engine
from mapfre_api import GestorDespachanteAPI

def executar_auditoria_semanal():
    print("\n[MODO AUDITORIA] Iniciando varredura de processos antigos e ociosos...")
    engine = obter_engine()
    
    # Busca credenciais do banco
    credenciais = database.carregar_credenciais_mapfre()
    
    if not credenciais:
        print(" !! Erro: Nenhuma credencial ativa encontrada no banco para auditoria.")
        return

    # Pega a primeira conta disponível (Rafael, Angélica, etc.)
    nome_conta = list(credenciais.keys())[0]
    dados_conta = credenciais[nome_conta]
    
    login_mapfre = dados_conta.get("login")
    senha_mapfre = dados_conta.get("senha")
    
    print(f" -> Usando a conta de {nome_conta.upper()} para realizar a auditoria...")
    
    api_mapfre = GestorDespachanteAPI(login_mapfre, senha_mapfre)
    
    try:
        api_mapfre.autenticar() 
    except Exception as e:
        print(f" !! Falha ao autenticar na Mapfre para a Auditoria: {e}")
        return
    
    with engine.begin() as conn:
        # Puxa processos abertos que estão há mais de 15 dias na base
        query = text("""
            SELECT tb_dim_id_processo_cod, tb_dim_no_sinistro 
            FROM tb_dim_processo 
            WHERE tb_dim_id_status_mapfre_cod NOT IN (22, 98)
              AND DATEDIFF(DAY, tb_dim_dt_abertura_sinistro, GETDATE()) > 15
        """)
        processos_suspeitos = conn.execute(query).fetchall()
        
        total_processos = len(processos_suspeitos)
        
        if total_processos == 0:
            print(" -> Nenhum processo antigo pendente de auditoria.")
            return

        print(f" -> {total_processos} processos suspeitos encontrados. Validando de forma silenciosa...")
        
        qtd_baixados = 0
        qtd_ainda_abertos = 0
        
        for index, (id_proc, sinistro) in enumerate(processos_suspeitos, 1):
            
            # MÁGICA DO TERMINAL LIMPO: Sobrescreve a mesma linha mostrando o progresso
            print(f"    [*] Progresso da varredura: {index}/{total_processos} processos analisados...", end="\r")
            
            # 1. Tenta buscar pelo ID direto (mais rápido)
            dados_mapfre = api_mapfre.buscar_processo_por_id(id_proc)
            status_real_mapfre = dados_mapfre.get("idStatusCorrente")
            
            # 2. Se falhar, tenta pela nova função de Sinistro
            if not status_real_mapfre:
                dados_mapfre = api_mapfre.consultar_por_sinistro(sinistro)
                status_real_mapfre = dados_mapfre.get("idStatusCorrente")
            
            # 3. Tratamento de segurança
            if not status_real_mapfre:
                texto_status = str(dados_mapfre.get("dsStatusCorrenteProcesso", "")).upper()
                if "FINALIZADO" in texto_status or "CONCLU" in texto_status:
                    status_real_mapfre = 22
                elif "CANCELADO" in texto_status:
                    status_real_mapfre = 98

            # 4. Faz a avaliação final
            if status_real_mapfre in [22, 98]:
                # Como usou \r antes, a gente quebra a linha (\n) para a mensagem de sucesso não apagar
                print(f"\n    [✓] SUCESSO! Processo {id_proc} (Sinistro {sinistro}) finalizado na Mapfre. Atualizando o banco...")
                fase_visual = 'PROCESSO FINALIZADO (Auditoria Automática)' if status_real_mapfre == 22 else 'PROCESSO CANCELADO (Auditoria Automática)'
                
                # =========================================================
                # ATUALIZA O BANCO DE DADOS
                # =========================================================
                # 1. Atualiza a Dimensão
                conn.execute(text("""
                    UPDATE tb_dim_processo
                    SET tb_dim_fase_processo = :fase,
                        tb_dim_id_status_mapfre_cod = :id_mapfre,
                        tb_dim_fl_alerta = 0
                    WHERE tb_dim_id_processo_cod = :id_proc
                """), {
                    "fase": fase_visual,
                    "id_mapfre": status_real_mapfre,
                    "id_proc": id_proc
                })
                
                # 2. Desativa da Fila
                conn.execute(text("UPDATE tb_fato_fila_envio SET tb_fato_ativo = 0 WHERE tb_fato_id_processo_cod = :id_proc"), {"id_proc": id_proc})
                
                # 3. NOVO: Registra a Data de Saída do Analista
                conn.execute(text("""
                    UPDATE tb_fato_historico_usuario_processo
                    SET tb_fato_data_saida = DATEADD(HOUR, -3, GETDATE()),
                        tb_fato_fl_responsavel_atual = 0
                    WHERE tb_fato_id_processo_cod = :id_proc
                      AND tb_fato_fl_responsavel_atual = 1
                """), {"id_proc": id_proc})
                
                qtd_baixados += 1
            else:
                # O processo estava aberto mesmo. Não 'printa' nada, só soma no contador invisível.
                qtd_ainda_abertos += 1
                
            time.sleep(0.5) # Pausa para não derrubar a API da Mapfre

        # Pula uma linha no final para não sobrescrever o contador de progresso
        print(f"\n -> [AUDITORIA CONCLUÍDA] {qtd_baixados} processos foram baixados sozinhos e {qtd_ainda_abertos} continuam abertos legitimamente!")

        