#%%
import os
from dotenv import load_dotenv

# Descobre a pasta real onde este arquivo config.py está rodando na nuvem
DIRETORIO_ATUAL = os.path.dirname(os.path.abspath(__file__))
caminho_env = os.path.join(DIRETORIO_ATUAL, '.env')

# Carrega o arquivo .env apontando para o caminho exato
load_dotenv(caminho_env)

# =========================================================================
# Conexão com o banco (DuckDB local -- ver DOCUMENTACAO_PROJETO.md sobre a
# migração do Fabric/SQL Server para DuckDB em 2026-07-13)
# =========================================================================
DUCKDB_PATH = os.getenv("DUCKDB_PATH")

# Trava de segurança para avisar se o arquivo .env não for lido
if not DUCKDB_PATH:
    print("!!! ALERTA CRÍTICO: O arquivo .env não foi lido corretamente !!!")

# =========================================================================
# Configurações de Execução do Robô
# =========================================================================
AMBIENTE = os.getenv("AMBIENTE", "PRODUCAO")
# Corrigido 2026-07-13: antes era hardcoded "= False" e ignorava o .env por
# completo -- a flag de segurança nunca respeitava o que estava configurado.
SIMULAR_ENVIO_API = os.getenv("SIMULAR_ENVIO_API", "True").lower() == "true"

# TEMPORÁRIO (2026-07-22): firewall do Azure SQL do Sinistro.net está bloqueando
# o IP do robô (ver DOCUMENTACAO_PROJETO.md), então a conciliação com
# Tb_VwEstoqueCompleto está inacessível. Usuário confirmou que hoje todos os
# processos da fila já estão cadastrados de fato no site -- reverter para
# "False" assim que o acesso ao banco do Sinistro.net for liberado de novo.
PULAR_CONCILIACAO_SINISTRONET = os.getenv("PULAR_CONCILIACAO_SINISTRONET", "False").lower() == "true"

#%%