# 🤖 RPA Integração: Mapfre ➔ Sinistro.net

Este projeto é um Robô de Automação de Processos (RPA) desenvolvido em Python que realiza a extração de dados do portal Gestor de Despachantes (Mapfre) e realiza o input estruturado na API do Sinistro.net. Toda a orquestração, fila de processos e logs de auditoria são gerenciados via banco de dados SQL Server.

Documentação completa (arquitetura, fluxo de execução, histórico de decisões e oportunidades de melhoria): [`DOCUMENTACAO_PROJETO.md`](DOCUMENTACAO_PROJETO.md). Guia pra replicar essa mesma arquitetura num robô de outro prestador: [`GUIA_NOVO_ROBO_PRESTADOR.md`](GUIA_NOVO_ROBO_PRESTADOR.md).

## 🏗️ Arquitetura

* **Linguagem:** Python 3.x
* **Banco de Dados:** SQL Server (T-SQL) — o banco do Microsoft Fabric usado até 2026-07-10 foi descontinuado; o `.env` precisa apontar para o servidor/banco novo assim que provisionado (Azure SQL, SQL Server local ou novo Fabric).
* **Autenticação de Banco:** Azure Identity (`InteractiveBrowserCredential` / Entra ID) — login via navegador, token injetado direto no `pyodbc.connect`.
* **Governança:** parametrização/credenciais 100% em tabelas `tb_config_*`, nada hardcoded no código.
* **Nomenclatura:** schema 100% português (`tb_bruto_`/`tb_dic_`/`tb_dom_`/`tb_dim_`/`tb_fato_`/`tb_config_`/`tb_log_`) — ver seção 2 da documentação completa.

## ⚙️ Pré-requisitos

1. Ter o Python instalado.
2. Ter o [ODBC Driver 17 ou 18 for SQL Server](https://learn.microsoft.com/pt-br/sql/connect/odbc/download-odbc-driver-for-sql-server) instalado na máquina.
3. Acesso autenticado (Entra ID) ao banco SQL Server da organização.

## 🚀 Como Configurar e Executar

### Passo 1: Configuração do Banco de Dados
No banco novo, execute os scripts da pasta `sql/` nesta ordem:
1. `01_create_tables.sql` *(schema completo: tabelas, índices, funções de normalização de telefone e views)*
2. `02_insert_initial_data.sql` *(dicionários/domínios e parâmetros de configuração — atualize os tokens/credenciais reais neste passo, os valores de exemplo são placeholders)*

Versões anteriores do schema (Microsoft Fabric, nomenclatura em inglês, já descontinuadas) ficam em `sql/_backup_schema_antigo/`, só como referência histórica.

### Passo 2: Instalação do Ambiente Python
Clone este repositório, crie um ambiente virtual e instale as dependências:
```bash
python -m venv venv
source venv/bin/activate  # No Windows use: venv\Scripts\activate
pip install -r requirements.txt
```

### Passo 3: Variáveis de Ambiente
Crie um `.env` na raiz do projeto (não é versionado) com:
```
FABRIC_SERVER=<servidor do banco novo>
FABRIC_DATABASE=<nome do banco novo>
AMBIENTE=PRODUCAO
SIMULAR_ENVIO_API=True
```
⚠️ **`SIMULAR_ENVIO_API=False` faz o robô criar acionamentos reais no Sinistro.net e disparar e-mails reais.** Ao configurar um ambiente novo, rode primeiro com `True` pra validar o fluxo completo (banco + envio) sem risco, e só depois mude pra `False`.

### Passo 4: Executar
```bash
python main.py
```
`main.py` decide o modo de execução pelo horário do dia (captura, enriquecimento ou auditoria semanal) — detalhes em `DOCUMENTACAO_PROJETO.md`, seção 3.
